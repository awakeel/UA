﻿import { Injectable } from '@angular/core';
import { AppConsts } from '@shared/AppConsts';

@Injectable()
export class AppAuthService {

    logout(reload?: boolean): void {
        abp.auth.clearToken();

        location.href = AppConsts.remoteServiceBaseUrl + '/account/logout'
        // <a href="@Url.Action("Logout", "Account")"><i class="fa fa-sign-out"></i> @L("Logout")</a>
        // if (reload !== false) {
        //     location.href = AppConsts.remoteServiceBaseUrl; // temp
        // }
    }
}
