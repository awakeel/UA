import { AppComponentBase } from '@shared/app-component-base';
import { Injector, ElementRef } from '@angular/core';

import { MetadataService } from '../cms/common/metadata.service';
import { DataEntityService } from '../cms/common/data-entity.service';
import { HelperService } from '../cms/common/helpers'

export abstract class DataComponentBase extends AppComponentBase {

    componentCatalogService: MetadataService;
    dataEntityService: DataEntityService;
    helperService: HelperService;

    constructor(injector: Injector) {
        super(injector);
        this.componentCatalogService = injector.get(MetadataService);
        this.dataEntityService = injector.get(DataEntityService);
        this.helperService = injector.get(HelperService);
    }
}
