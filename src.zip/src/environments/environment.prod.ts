// "Production" enabled environment

export const environment = {
    production: true,
    hmr: false,
    metaDataAPI: '',
    actionsAPI: '',
    dataAPI: '',
    dataAPIProcedure: '',
    remoteAPI: '/api/data/?',
    formAPI: 'http://www.google.com',
    searchAPI: '/EX_SQLSVC/DynamicSearch.html',
    local: false
};
