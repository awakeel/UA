import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ModalModule } from 'ngx-bootstrap';
import { TreeModule } from 'angular-tree-component';
import { DynamicFormModule } from './dynamic-form/dynamic-form.module';
import { PageDesignerRoutingModule } from './page-designer-routing.module';
import { PageDesignerComponent } from './page-designer.component';
import { PageComponent } from 'cms/page-designer/page/page.component';
import { WidgetComponent } from 'cms/page-designer/page/widget';

@NgModule({
  imports: [
    CommonModule,
    PageDesignerRoutingModule,
    DynamicFormModule,
    TreeModule,
    ModalModule.forRoot(),
  ],
  declarations: [PageDesignerComponent, PageComponent,
    WidgetComponent],
  exports: [PageComponent, WidgetComponent]
})
export class PageDesignerModule { }
