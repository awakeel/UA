import { Component, OnInit, Input, ViewChild, OnDestroy, AfterViewInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Observable } from 'rxjs/Rx';
import '../../common/rxjs-extensions';

import { BsModalService } from 'ngx-bootstrap';
import { BsModalRef } from 'ngx-bootstrap';
import { WidgetComponent } from './widget';
import { CmsServoceService } from '../services';

@Component({
  selector: 'app-page',
  templateUrl: './page.component.html',
  styleUrls: ['./page.component.css'],
  providers: [CmsServoceService]
})
export class PageComponent implements OnInit, OnDestroy {
  @ViewChild(WidgetComponent)
  private widget: WidgetComponent;

  public mRef: BsModalRef;
  thisPage: any;
  sub: any; sub1: any;
  pageId: number;
  widgets: any[];
  isDataLoaded: boolean;
  theZone: any;

  widgetCatalog: any[];

  constructor(private router: Router,
    private route: ActivatedRoute,
    private cmsService: CmsServoceService, private modalService: BsModalService
  ) {
    this.isDataLoaded = false;
  }

  ngOnInit() {
    this.sub = this.route.params
      .delay(100)
      .map(params => {
        this.pageId = params['id'];
        return this.pageId;
      })
      .switchMap(id => this.cmsService.getPagesById(null, id))
      .subscribe((res) => {
        if (res) {
          this.thisPage = res[0];
        }
        this.isDataLoaded = true;
        this.loadWidgetsData();
        this.loadWidgetsCatalog();
      });
  }


  loadWidgetsData() {
    this.widgets = [];
    this.cmsService.getPageWidgets(null, this.pageId)
      .subscribe((widget) => {
        if (widget) {

          this.widgets.push(widget);
        }
      },
      (err) => {
        alert('widgetData \n' + err);
      }, () => {
        console.log('widgets => completed');
      });
  }
  loadWidgetsCatalog() {
    this.widgetCatalog = [];
    this.cmsService.getWidgetCatalog('DL_Widgets')
      .subscribe((res) => {

        if (res) {
          const wc = {
            type: 'checkbox',
            label: '',
            DL_WebPartType: res.DL_WebPartType,
            name: 'DL_Id',
            id: res.DL_Id,
            imgUrl: '',
            extendedComponent: '',
            version: '1.0.0',
            description: 'This widget is list data in exformatic selected theme'
          };
          if (res.DL_ComponentName) {
            wc.label = res.DL_ComponentName + '[' + res.DL_WebPartType + ']';
          } else {
            wc.label = res.DL_WebPartType;
          }
          if (res.DL_ComponentName) {
            wc.extendedComponent = res.DL_ComponentName;
          }
          if (res.DL_WebPartType.toLowerCase() === 'list') {
            wc.imgUrl = '../../../../assets/images/list.png';
          } else if (res.DL_WebPartType.toLowerCase() === 'detail'
          && !res.DL_ComponentName) {
            wc.imgUrl = '../../../../assets/images/detail.png';
          } else {
            wc.imgUrl = '../../../../assets/images/form.png';
          }
          this.widgetCatalog.push(wc);
        }
      },
      (err) => {
        alert('loadWidgetsCatalog\n ' + err);
      }, () => {
        this.isDataLoaded = true;
      });
  }

  filterByZone = (zone) => {
    return this.widgets.filter((item) => {
      return item.DL_Zone.trim().toLowerCase() === zone;
    });
  }
  loadWidgetCatalog(pageNum, zone, widgetList) {
    if (this.isDataLoaded) {
      this.theZone = zone;
      this.mRef = this.modalService.show(widgetList);
    }
  }
  addWidget = (id, widgetType, zone) => {

    const theWidget = {
      'DL_Id': this.getRandomInt(1, 99999),
      'DL_PageID': this.thisPage.DL_Id,
      'DL_WebPart': '',
      'DL_WebPartType': widgetType,
      'DL_Zone': zone,
      'DL_View': '',
      'DL_Where': '',
      'DL_OrderBy': '',
      'DL_Column1': '',
      'DL_Column2': null,
      'DL_Action1': '',
      'DL_Menu': null,
      'DL_Sequence': 0
    };
    this.widgets.push(theWidget);

  }
  getRandomInt = (min, max) => {
    return Math.floor(Math.random() * (max - min + 1)) + min;
  }
  deleteWidget(event) {
    const widgetToDelete = this.widgets.find(w => w.DL_Id === event);
    const index = this.widgets.indexOf(widgetToDelete);
    if (index > -1) {
      this.widgets.splice(index, 1);
    }

    // Service call to add in DB
  }
  ngOnDestroy() {
    this.sub.unsubscribe();
  }

}
