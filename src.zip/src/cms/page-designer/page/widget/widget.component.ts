import { Component, OnInit, Input, Output, EventEmitter, TemplateRef } from '@angular/core';
import { BsModalRef } from 'ngx-bootstrap';
import { BsModalService } from 'ngx-bootstrap';


export interface DLPageWidget {
  DL_Id: string;
  DL_PageID: string;
  DL_WebPart: string;
  DL_WebPartType: string;
  DL_Zone: string;
  DL_View?: string;
  DL_Where?: string;
  DL_OrderBy?: string;
  DL_Column1?: string;
  DL_Column2?: string;
  DL_Action1?: string;
  DL_Action2?: string;
  DL_ComponentName?: string;
  DL_Menu?: string;
  DL_Sequence?: string;
  DL_Columns?: string;
  DL_EntityType?: string;
}

@Component({
  selector: 'app-widget',
  templateUrl: './widget.component.html',
  styleUrls: ['./widget.component.css']
})
export class WidgetComponent implements OnInit {
  @Input() widgetData: any;
  modalRef: BsModalRef;

  @Output()
  public removeWidget: EventEmitter<any> = new EventEmitter<any>();

  widgetConfig = [
    {
      type: 'input',
      label: 'Page ID',
      name: 'DL_PageID',
      required: true,
      placeholder: 'Enter page name'
    },
    {
      type: 'input',
      label: 'Web Part Name',
      name: 'DL_WebPart',
      placeholder: 'Enter WebPart Name',
      required: true,
    },
    {
      type: 'select',
      label: 'Zone',
      name: 'DL_Zone',
      options: ['left', 'center', 'right'],
      placeholder: 'Select an option',
      required: true,
    },
    {
      type: 'input',
      label: 'View',
      name: 'DL_View',
      placeholder: 'Enter View',
      required: true,
    },
    {
      type: 'input',
      label: 'Where',
      name: 'DL_Where',
      placeholder: 'Enter Where clause',
      required: true,
    }
    ,
    {
      type: 'input',
      label: 'Order By',
      name: 'DL_OrderBy',
      placeholder: 'Enter DL_OrderBy',
      required: true,
    },
    {
      type: 'input',
      label: 'Column1',
      name: 'DL_Column1',
      placeholder: 'Enter Column1',
      required: true,
    },
    {
      type: 'input',
      label: 'Action1',
      name: 'DL_Action1',
      placeholder: 'Enter Action1',
      required: true,
    },
    {
      type: 'input',
      label: 'Action2',
      name: 'DL_Action2',
      placeholder: 'Enter Action2',
      required: true,
    },
    {
      type: 'input',
      label: 'Custom Component Name',
      name: 'DL_ComponentName',
      placeholder: 'Enter Component Name',
      required: true,
    }
    ,
    {
      type: 'input',
      label: 'Sequence',
      name: 'DL_Sequence',
      placeholder: 'Enter Sequence',
      required: true,
    },
    {
      type: 'input',
      label: 'Columns',
      name: 'DL_Columns',
      placeholder: 'Enter Columns',
      required: true,
    },
    {
      type: 'select',
      label: 'Entity Type',
      name: 'DL_EntityType',
      options: ['TABLE', 'PROCEDURE', 'VIEW'],
      placeholder: 'Select an option',
      required: true
    },

    {
      label: 'Submit',
      name: 'submit',
      type: 'button'
    }
  ];

  constructor(private modalService: BsModalService) { }

  ngOnInit() {

  }
  public openModal(template: TemplateRef<any>) {
    this.modalRef = this.modalService.show(template);
  }
  formSubmit = (value) => {
    alert(value);
  }


  handleRemove(id: any ) {
    this.removeWidget.emit(id);
  }
}
