import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { PageDesignerComponent } from 'cms/page-designer/page-designer.component';
import { PageComponent } from 'cms/page-designer/page/page.component';
import { WidgetComponent } from 'cms/page-designer/page/widget';
const routes: Routes = [
  {
    path: '', component: PageDesignerComponent,
    children: [
      {  path: 'designer', component: PageComponent},
      {  path: ':id', component: PageComponent}

    ]
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class PageDesignerRoutingModule { }
