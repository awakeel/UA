import { Component, OnInit, Injectable, ViewChild, TemplateRef } from '@angular/core';
import { Router, RouterState } from '@angular/router';
import { BsModalService } from 'ngx-bootstrap';
import { BsModalRef } from 'ngx-bootstrap';
import { Observable } from 'rxjs/Rx';
import '../common/rxjs-extensions';

import { EntityDataService } from './services';
import { TreeNode, TREE_ACTIONS, KEYS, IActionMapping } from 'angular-tree-component';
import { PageComponent } from './page';

const actionMapping: IActionMapping = {
  mouse: {
    contextMenu: (tree, node, $event) => {
      $event.preventDefault();
      // alert(`context menu for ${node.data.name}`);
    },
    dblClick: (tree, node, $event) => {

      if (node.hasChildren) {
        TREE_ACTIONS.TOGGLE_EXPANDED(tree, node, $event);
      }
    },
    click: (tree, node, $event) => {
      $event.shiftKey
        ? TREE_ACTIONS.TOGGLE_SELECTED_MULTI(tree, node, $event)
        : TREE_ACTIONS.TOGGLE_SELECTED(tree, node, $event);
    }
  },
  keys: {
    [KEYS.ENTER]: (tree, node, $event) => alert(`This is ${node.data.name}`)
  }
};

@Component({
  selector: 'app-page-designer',
  templateUrl: './page-designer.component.html',
  styleUrls: ['./page-designer.component.css'],
  providers: [EntityDataService]
})
export class PageDesignerComponent implements OnInit {
  @ViewChild(PageComponent)
  private pageComponent: PageComponent;
  public modalRef: BsModalRef;
  pages: any[];

  isDataLoaded: boolean;
  nodata: string;

  nodes: any[];
  sub: any;
  customTemplateStringOptions = {
    // displayField: 'subTitle',
    isExpandedField: 'expanded',
    idField: 'uuid',
    displayField: 'name',
    getChildren: this.getChildren.bind(this),
    actionMapping,
    nodeHeight: 23,
    levelPadding: 10,
    allowDrag: true,
    useVirtualScroll: true
  };

  pageConfig = [
    {
      type: 'input',
      label: 'Page Name',
      name: 'DL_Page',
      required: true,
      placeholder: 'Enter page name'
    },
    {
      type: 'input',
      label: 'Page title',
      name: 'DL_PageTitle',
      placeholder: 'Enter page title',
      required: true,
    },
    {
      type: 'select',
      label: 'Page Template',
      name: 'DL_PageTemplate',
      options: ['3-col', '2-col', '1-col'],
      placeholder: 'Select an option',
      required: true,
    },
    {
      label: 'Submit',
      name: 'submit',
      type: 'button'
    }
  ];
  constructor(private router: Router,
    private entityDataService: EntityDataService,
    private modalService: BsModalService) {
    this.isDataLoaded = false;
    this.nodata = '';
    // temporary
    this.nodes = [
      {
        uuid: -1,
        expanded: true,
        name: 'Site 1',
        level: 'SITE',
        hasChildren: true,
      }];

  }

  ngOnInit() {

    this.loadPagesTree();

  }

  loadPagesTree() {
    this.isDataLoaded = false;
    const children: any[] = [];
    this.entityDataService.getPages(null)
      .subscribe(
      (d) => {
        if (d) {
          children.push(
            {
              uuid: d.DL_Id,
              name: d.DL_Page,
              title: d.DL_PageTitle,
              hasChildren: true,
              level: 'PAGE'
            }
          );
        }
      }, (err) => { console.log(err); }, () => {
        this.isDataLoaded = true;
        this.nodes[0].children = children;
      });
  }



  getChildren(node: any) {
    console.log(node.data);
    return new Promise((resolve, reject) => {
      setTimeout(() => resolve(this.entityDataService
        .getPageWidgetsPromise(null, node.data.uuid).then(
        (res) => {
          const data = res.json();
          let d;
          if (data) {
            d = data['DL_ENTITYDATA'];
            if (d) {
              d = d['DL_PageWidgets'];
            }
            if (d) {
              d = d.filter((e) => {
                return e.DL_PageID === node.data.uuid.toString();
              }).map((a) => {
                return {
                  uuid: a.DL_Id,
                  name: a.DL_WebPartType,
                  title: a.DL_WebPart,
                  hasChildren: false,
                  level: 'WIDGET'
                };
              });

            }
          }

          return d;
        })), 300);
    });
  }


  onEvent(event) {
    console.log('main event', event);
  }

  loadNodeContent($event, data) {
    $event.stopPropagation();
    if (data) {

      switch (data.level) {

        case 'PAGE':

          this.router.navigate(['cms/design/page', data.uuid]).then((d) => {
            console.log('param value', d);
          });

          break;
        case 'WIDGET':
          alert('This is Widget node');
          // this.loadWidgetContent(data);
          break;
        default:
          break;
      }
    }

  }
  public openModal(template: TemplateRef<any>) {
    this.modalRef = this.modalService.show(template);
  }
  formSubmitted(value) {
    if (value) {

      const theNode = {
        uuid: this.getRandomInt(0, 98888),
        name: value.DL_Page,
        title: value.DL_PageTitle,
        hasChildren: true,
        level: 'PAGE'
      };
      this.nodes = this.nodes[0].children.concat(theNode);
      console.log(theNode);
      // this.nodes[0].children.push(theNode);
      this.modalRef.hide();

      // call service to submit form data
      // this.entityDataService.savePage(null, value).subscribe(
      //   (res) => {
      //     if (res.status === 'ok') {
      //       this.modalRef.hide();
      //     }
      //   },
      //   (err) => {
      //     alert(err.statusText);
      //   }
      // );

    }
  }
  getRandomInt = (min, max) => {
    return Math.floor(Math.random() * (max - min + 1)) + min;
  }
  private loadTreeData() {
    const newarr = [];
    const unique = {};

    this.pages.forEach(function (item) {
      if (!unique[item.DL_PageID]) {
        newarr.push(item);
        unique[item.DL_PageID] = item;
      }
    });

    return newarr.map(function (row, i) {
      return {
        name: row.DL_Page, uuid: row.DL_PageID, level: 'PAGE'
      };

    });

  }

}
