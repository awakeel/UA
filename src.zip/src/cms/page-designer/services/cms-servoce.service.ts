import { Injectable } from '@angular/core';
import { Http, RequestOptions } from '@angular/http';
import { Headers } from '@angular/http';
import { Observable } from 'rxjs/Rx';
import '../../common/rxjs-extensions';

import { environment } from '../../../environments/environment';

const baseDataAPI: string = environment.dataAPI;
const baseDataAPIProcedure: string = environment.dataAPIProcedure;

@Injectable()
export class CmsServoceService {
  constructor(private http: Http) { }

  public getPages(config): Observable<any> {
    const dataSource = 'DL_pages';
    const apiUrl = this.buildDataUri(config, 'DL_pages');

    return this.http
      .get(apiUrl)
      .map(res => res.json())
      .map(d => d.DL_ENTITYDATA)
      .map(d => {

        return d[dataSource];
      });

  }
  public getPagesById(config, page?: number): Observable<any> {
    const dataSource = 'DL_pages';
    const apiUrl = this.buildDataUri(config, 'DL_pages');

    return this.http
      .get(apiUrl)
      .map(res => res.json())
      .map(d => d.DL_ENTITYDATA)
      .map(d => {
        return d[dataSource].filter(p => {
          return p.DL_Id === page;
        });
      });

  }
  public getPageWidgets(config, page?: number, records?: number): Observable<any> {

    const dataSource = 'DL_PageWidgets';
    const apiUrl = this.buildDataUri(config, 'DL_PageWidgets');

    return this.http
      .get(apiUrl)
      .map(res => res.json())
      .map(d => d.DL_ENTITYDATA)
      .flatMap(d => {
        if (d.DL_PageWidgets && this.isArray(d.DL_PageWidgets)) {
          return d.DL_PageWidgets.filter((a) => {
            return a.DL_PageID === page;
          });
        } else {
          return Observable.empty();
        }
      });

  }

  public getWidgetCatalog(entityName, entityType?): Observable<any> {

    const dataSource = 'DL_Widgets';
    const apiUrl = this.buildApiUrl(entityName, entityType);
    console.log(apiUrl);
    return this.http
      .get(apiUrl)
      .map(res => res.json())
      .map(d => d.DL_ENTITYDATA)
      .flatMap(d => {
        if (d && d[entityName]) {

          return d[entityName];
        } else {
          return Observable.empty();
        }
      });
  }
  buildDataUri = (config, dataSource) => {
    let where, orderBy;
    (where = ''), (orderBy = '');
    // let DL_Id = this.getParameterByName(config.DL_Page);
    // if (!DL_Id) {
    //     DL_Id = '0';
    // }
    // const where = config.DL_Where.replace('%' + config.DL_Page + '%', DL_Id);
    // let orderBy = config.DL_OrderBy;
    // if (!config.DL_OrderBy) {
    //     orderBy = '';
    // }
    let apiUrl = `/public/assets/localData/${dataSource}.json`;

    if (environment.local === false && environment.production === true) {
      if (!config.DL_EntityType) {
        apiUrl =
          `${baseDataAPI}${config.DL_View}/?where=${where}&OrderBy=${orderBy}&date=` +
          new Date().getTime();
      } else if (
        config.DL_EntityType &&
        config.DL_EntityType.trim().toLowerCase() === 'procedure'
      ) {
        apiUrl = `${baseDataAPIProcedure}${config.DL_View}  ${where}`;
      }
    }
    return apiUrl;
  }
  isArray = data => {
    return Object.prototype.toString.call(data) === '[object Array]';
  }

  buildApiUrl = (entityName, entityType) => {
    let where, orderBy;
    (where = ''), (orderBy = '');

    let apiUrl = `../../assets/localData/${entityName}.json`;

    if (environment.production === true) {
      if (!entityType) {
        apiUrl =
          `${baseDataAPI}${entityName}/?where=${where}&OrderBy=${orderBy}&date=` +
          new Date().getTime();
      } else if (
        entityType &&
        entityType.trim().toLowerCase() === 'procedure'
      ) {
        apiUrl = `${baseDataAPIProcedure}${entityName}  ${where}`;
      }
    }
    return apiUrl;
  }
}
