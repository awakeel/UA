import { TestBed, inject } from '@angular/core/testing';

import { CmsServoceService } from './cms-servoce.service';

describe('CmsServoceService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [CmsServoceService]
    });
  });

  it('should be created', inject([CmsServoceService], (service: CmsServoceService) => {
    expect(service).toBeTruthy();
  }));
});
