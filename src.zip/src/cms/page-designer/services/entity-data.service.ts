import { Injectable } from '@angular/core';
import { Http, RequestOptions } from '@angular/http';
import { Headers } from '@angular/http';
import { Observable } from 'rxjs/Rx';
import '../../common/rxjs-extensions';
// import { TreeviewItem, TreeItem } from 'ngx-treeview';

import { environment } from '../../../environments/environment';

const baseDataAPI: string = environment.dataAPI;
const baseDataAPIProcedure: string = environment.dataAPIProcedure;

@Injectable()
export class EntityDataService {
  constructor(private http: Http) { }

  public getPages(config): Observable<any> {
    const dataSource = 'DL_pages';
    const apiUrl = this.buildDataUri(config, 'DL_pages');

    return this.http
      .get(apiUrl)
      .map(res => res.json())
      .map(d => d.DL_ENTITYDATA)
      .flatMap(d => {
        return d[dataSource];
      });

  }
  public savePage(config, pageData): Observable<any> {
    const apiUrl = this.buildDataUri(config, 'DL_pages');
    const headers = new Headers({ 'Content-Type': 'application/json' });
    const options = new RequestOptions({ headers: headers });
    return this.http
      .post(apiUrl, pageData, options)
      .map((res) => {
        return res.json();
      })
      .catch(this.handleErrorObservable);
  }
  public extractData(res: Response, i: number) {
    const body = res.json();
    return body || {};
  }
  private handleErrorObservable(error: Response | any) {
    console.error(error.message || error);
    return Observable.throw(error.message || error);
  }
  public getPageWidgets(data, page?: number, records?: number): Observable<any> {
    const apiUrl = this.buildDataUri(data, 'DL_PageWidgets');

    return this.http
      .get(apiUrl)
      .map(res => res.json())
      .map(d => d.DL_ENTITYDATA)

      .flatMap(d => {
        if (d && d.DL_PageWidgets) {
          return this.isArray(d.DL_PageWidgets)
            ? d.DL_PageWidgets
            : [d[d.DL_PageWidgets]];
        } else {
          return [];
        }
      });
    // .take(count)
    // .distinctUntilChanged();
  }

  public getPageWidgetsPromise(data, page?: number, records?: number): Promise<any> {
    const apiUrl = this.buildDataUri(data, 'DL_PageWidgets');

    return this.http
      .get(apiUrl).toPromise();
    // .map(res => res.json())
    // .map(d => d.DL_ENTITYDATA)
    // .flatMap(d => {
    //  return d.DL_PageWidgets;
    // }).toPromise();
    // .take(count)
    // .distinctUntilChanged();
  }
  public getWidgetMenu(data, page?: number, records?: number): Observable<any> {
    const apiUrl = this.buildDataUri(data, 'DL_WidgetMenu');

    return this.http
      .get(apiUrl)
      .map(res => res.json())
      .map(d => d.DL_ENTITYDATA)
      .flatMap(d => {
        if (d && d.DL_WidgetMenu) {

          return this.isArray(d.DL_WidgetMenu)
            ? d.DL_WidgetMenu
            : [d[d.DL_WidgetMenu]];
        } else {
          return [];
        }
      });
    // .take(count)
    // .distinctUntilChanged();
  }
  buildDataUri = (config, dataSource) => {
    let where, orderBy;
    (where = ''), (orderBy = '');
    // let DL_Id = this.getParameterByName(config.DL_Page);
    // if (!DL_Id) {
    //     DL_Id = '0';
    // }
    // const where = config.DL_Where.replace('%' + config.DL_Page + '%', DL_Id);
    // let orderBy = config.DL_OrderBy;
    // if (!config.DL_OrderBy) {
    //     orderBy = '';
    // }
    let apiUrl = `/public/assets/localData/${dataSource}.json`;

    if (environment.local === false && environment.production === true) {
      if (!config.DL_EntityType) {
        apiUrl =
          `${baseDataAPI}${config.DL_View}/?where=${where}&OrderBy=${orderBy}&date=` +
          new Date().getTime();
      } else if (
        config.DL_EntityType &&
        config.DL_EntityType.trim().toLowerCase() === 'procedure'
      ) {
        apiUrl = `${baseDataAPIProcedure}${config.DL_View}  ${where}`;
      }
    }
    return apiUrl;
  }
  isArray = data => {
    return Object.prototype.toString.call(data) === '[object Array]';
  }

}
