

import { Component, OnInit, Injector } from '@angular/core';
import { Router, ActivatedRoute, RouterState } from '@angular/router';
import { Observable } from 'rxjs/Rx';
import '../common/rxjs-extensions';

import { DynamicPageComponent } from './dynamic-page';
import { TopbarModule } from './../shared/topbar/topbar.module';
import { DataComponentBase } from 'shared/data-component-base';

@Component({
  selector: 'app-widgets',
  templateUrl: './widgets.component.html',
  styleUrls: ['./widgets.component.css'],

})
export class WidgetsComponent extends DataComponentBase implements OnInit {
  public pages: Array<any>;
  public isDataLoaded: boolean;

  constructor(injector: Injector) {
    super(injector);
  }

  ngOnInit() {
    this.pages = new Array<any>();
    this.componentCatalogService.getDataByEntityName('DL_Pages')
      .delay(100)
      .subscribe((d) => {
        if (d) {

          this.pages.push(d);
        }
      }, (err) => {
        console.log(err);
      }, () => {
        this.isDataLoaded = true;
      });
  }

}
