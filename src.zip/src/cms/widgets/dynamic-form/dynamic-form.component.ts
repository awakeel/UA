
import { Component, Input, Injector } from '@angular/core';
import { WebpartComponent, Widget } from '../../common';

import { DataComponentBase } from '@shared/data-component-base';

@Component({
  selector: 'app-dynamic-form',
  templateUrl: './dynamic-form.component.html',
  styleUrls: ['./dynamic-form.component.css']
})
export class DynamicFormComponent extends DataComponentBase implements WebpartComponent {

  @Input() data: any;

  constructor(injector: Injector) {
    super(injector);
  }
}
