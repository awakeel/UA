export * from './select-detail.component';
