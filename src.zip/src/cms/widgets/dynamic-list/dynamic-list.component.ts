﻿import { Component, Input, OnInit, Injector, ViewChild, OnDestroy } from '@angular/core';
import { Http, URLSearchParams } from '@angular/http';
import { Router, ActivatedRoute, RouterState } from '@angular/router';
// import { DomSanitizer } from '@angular/platform-browser';
import { DynamicIframeComponent } from '../dynamic-iframe';
import { WidgetMenuComponent } from 'cms/shared/widget-menu';

import { Observable, Subject } from 'rxjs/Rx';
import '../../common/rxjs-extensions';

import { WebpartComponent } from '../../common';


import { DLCMSView } from '../../common/models';
import { DataComponentBase } from '@shared/data-component-base';
import { environment } from '../../../environments/environment';
const formAPI: string = environment.formAPI;
@Component({
  selector: 'app-dynamic-list',
  // host: { '[id]': 'id' },
  templateUrl: './dynamic-list.component.html',
  styleUrls: ['./dynamic-list.component.css'],
  // providers: [HelperService]
})
export class DynamicListComponent extends DataComponentBase implements WebpartComponent, OnInit, OnDestroy {

  @ViewChild(WidgetMenuComponent) hm: WidgetMenuComponent;
  @ViewChild(WidgetMenuComponent) lm: WidgetMenuComponent;
  @Input() data: any;
  @Input() widgetMenuData: Observable<any>;

  entityData: any[] = [];
  menuData: any[] = [];
  menuDataLoaded: boolean;

  private apiUrl: string;

  public isDataLoaded: boolean;
  private ngUnsub: Subject<any> = new Subject();

  id: string;

  randomText: string;
  public nodata: string;

  constructor(private router: Router,
    injector: Injector, private route: ActivatedRoute
  ) {
    super(injector);
    this.isDataLoaded = false;
    this.randomText = Math.random().toString(3);
    this.nodata = '';
    this.menuDataLoaded = false;
  }

  ngOnInit() {
    this.entityData = [];
    this.loadData();
    this.loadMenuData();
    this.id = this.data.DL_View;
    // this.hasWidgetMenu = this.data['DL_RelatedActions'] !== undefined
  }
  ngOnDestroy() {
    this.ngUnsub.next();
    this.ngUnsub.unsubscribe();
  }

  public loadData() {
    this.entityData = [];
    this.isDataLoaded = false;
    if (!this.data.DL_View) {
      this.isDataLoaded = true;
      return;
    };
    const obsComb = Observable.combineLatest(this.route.params, this.route.queryParams,
      (params, qparams) => ({ params, qparams }));

    obsComb
      .takeUntil(this.ngUnsub)
      .subscribe(ap => {

        this.dataEntityService.getEntityData(this.data,null,
          ap.params['page'] || ap.qparams['page'],
          ap.qparams['entityId'],
          ap.qparams['entityName'],
          this.appSession.tenant.tenancyName,
          this.appSession.user.emailAddress)
          .takeUntil(this.ngUnsub)
          .subscribe(d => {
            if (d) {
              this.isDataLoaded = true;

              this.entityData.push(d);
            }
          },
          err => { this.notify.error(`${this.data.DL_WebPart} => ${err}`); },
          () => { if (!this.entityData.length) { this.nodata = `Der er ingen ${this.data.DL_WebPart}`; } });
      });

  }

  getTitle = (s) => {
    if (s.indexOf('=') > -1) {
      return s.split('=')[1];
    } else {
      return s.trim();
    }
  }

  getColumns = (s) => {
    if (s && s !== '') {
      if (s.indexOf(',') > -1) {
        return s.split(',');
      }
      return [s];
    }

  }
  getDataValue = (column) => {
    if (column.indexOf('=') > -1) {
      return column.split('=')[0];
    } else {
      return column;
    }
  }
  gotoObjectWrapper(func: string, item) {

    const params = this.getArgs(func);
    params.forEach((v) => {
      const percentEx = /\%(.*?)\%/;
      let d = v.match(percentEx);
      let keep = '';
      let found = false
      if (d !== null) {
        v = d.pop();
        found = true;
        keep = `%${v}%`;
      }
      console.log(keep + v);
      if (found) {
        func = func.replace(keep, "'" + item[v] + "'");
        console.log(func);
      }
      const hash = /\#(.*?)\#/;
      d = v.match(hash);
      keep = '';
      found = false
      if (d !== null) {
        v = d.pop();
        found = true;
        keep = `#${v}#`;
      }
      console.log(keep + v);
      if (found) {
        console.log(keep);
        console.log(this.getParameterByName(this.data.DL_Page));
        func = func.replace(keep, this.getParameterByName(this.data.DL_Page));
        console.log(event);
      }
    });
    eval(func);
    return false;
  }
  public goToObject(pageNum, entity, id) {
    this.router.navigate(['/pages'], { queryParams: { page: pageNum, entityId: id, entityName: entity } });
  }
  public openDocument(url) {
    window.open(url);
  }
  loadEntity(entity, id, url) {
    console.log($(this.elementRef.nativeElement).closest("app-dynamic-page"));
    let parentEl = $(this.elementRef.nativeElement).closest("app-dynamic-page");
    console.log(parentEl.find('app-dynamic-iframe').find("#DL_Information"));
    parentEl.find('app-dynamic-iframe').find("Iframe")['src'] = `${formAPI}/${url}`;
    console.log('I am loading ', entity, id, url)
  }
  getParameterByName(name: any) {
    const url = window.location.href;
    name = name.replace(/[\[\]]/g, '\\$&');
    const regex = new RegExp('[?&]' + name + '(=([^&#]*)|&|#|$)'),
      results = regex.exec(url);
    if (!results) { return null };
    if (!results[2]) { return '' };
    return decodeURIComponent(results[2].replace(/\+/g, ' '));
  }
  IsString(obj) {
    return obj !== undefined && obj != null && obj.toLowerCase !== undefined;
  }
  getArgs(str) {
    if (!str) { return []; }
    return /\(\s*([^)]+?)\s*\)/.exec(str)[1].split(/\s*,\s*/);


  }
  onActionClick(event, id) {

    new Function(event)();
  }
  onMenuClick(event) {
    new Function(event)();
  }
  refresh() {
    this.entityData = [];
    this.loadData();
  }
  onButtonClick(event) {

    new Function(event)();
  }

  isArray = (data) => {
    return (Object.prototype.toString.call(data) === '[object Array]');
  }

  filterByMenuType = (type) => {

    if (type !== undefined && type) {
      if (this.menuData) {
        return this.menuData.filter(t => t.DL_Type == type);
      }
    }
  }

  checkRole(row) {
    return false;


  }
  loadMenuData() {

    this.dataEntityService.getMenuData(this.data)
      //.filter(d => /* d['DL_PageWidgetId'] === this.config.DL_PageWidgetId  && */ d['DL_Type'] === 'row')
      .subscribe(d => {
        if (d && d['DL_PageWidgetId'] === this.data.DL_PageWidgetId) {
          this.menuData.push(d);
          this.menuDataLoaded = true;
        }
      },
      err => console.log(`${this.data.DL_WebPart} => ${err}`));
  }
  checkPrimary(row) {
    return false;
  }
}

