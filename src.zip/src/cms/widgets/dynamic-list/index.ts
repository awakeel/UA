export * from './dynamic-list.component';

