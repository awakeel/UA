export * from './dynamic-search.component';
