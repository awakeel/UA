import {
  Component,
  OnInit,
  Input,
  Output,
  EventEmitter,
  ViewChild,
  Injector
} from '@angular/core';

import {
  DsSearchParams,
  DsCoreObjects,
  DsSearchPagingParams,
  DsSettingsDto
} from '../type';

import {
  AppComponentBase
} from '@shared/app-component-base';

@Component({
  selector: 'app-search-form',
  templateUrl: './search-form.component.html',
  styleUrls: ['./search-form.component.css']
})
export class SearchFormComponent extends AppComponentBase implements OnInit {

  // @Input() entityData:any;
  @Input() dsSearchParams: DsSearchParams;

  private dsSettingsDto: DsSettingsDto;
  private dsCoreObj: DsCoreObjects;
  constructor(injector: Injector) {
    super(injector)
  }

  ngOnInit() {
    this._initForm();
  }

  _initForm = () => {
    try {
      if (this.dsSearchParams.Ds_Entity === '' ||
        this.dsSearchParams.Ds_SearchParameters === '' ||
        this.dsSearchParams.Ds_DisplayParameters === '' ||
        this.dsSearchParams.Ds_ClickAction === '') {
        this.notify.error(`Dynamic Search - parameters missing`);
        return;
      }

      this.dsCoreObj.Ds_ArrSearchParameters = this.dsSearchParams.Ds_SearchParameters.split(',');

      this.dsCoreObj.Ds_ArrDisplayParameters = this.dsSearchParams.Ds_DisplayParameters.split(',');

      // Managing data in Settings Array
      this.dsSettingsDto = {
        Entity: this.dsSearchParams.Ds_Entity,
        DisplayParams: this.dsCoreObj.Ds_ArrDisplayParameters,
        OrderByParams: this.dsSearchParams.Ds_OrderBy,
        XPathId: null,
        XPathValue: null
      }

      this._addSettings(this.dsSettingsDto);

    } catch (err) {
      // console.log(`${this._initForm.toString()} => ${err}`);
      this.notify.error(`${this._initForm.toString()} => ${err}`)
    }
  }

  _visibleControls = () => {
    try {

    } catch (err) {
      this.notify.error(`${this._visibleControls.toString()} => ${err}`);
    }
  }

  _addSettings = (oSettingsDto: DsSettingsDto) => {
    try {
      if (this.dsCoreObj.Ds_ArrSettings[oSettingsDto.Entity] == null) {
        if (oSettingsDto.XPathValue === 'undefined' ||
          oSettingsDto.XPathId === 'undefined') {
          alert(`${this._addSettings} ${oSettingsDto.Entity}`)
        }
        if (oSettingsDto.XPathId === '') {
          oSettingsDto.XPathId = 'DL_Id';
        }
        const oSettings = new Array();
        // oSettings['xml'] =
        oSettings['DisplayParameters'] = oSettingsDto.DisplayParams;
        oSettings['OrderBy'] = oSettingsDto.OrderByParams;
        oSettings['XPathDLValue'] = oSettingsDto.XPathValue;
        oSettings['XPathDLId'] = oSettingsDto.XPathId;

        this.dsCoreObj.Ds_ArrSettings[oSettingsDto.Entity] = oSettings;
      }
    } catch (err) {
      this.notify.error(`${this._addSettings} => ${err}`);
    }
  }
}
