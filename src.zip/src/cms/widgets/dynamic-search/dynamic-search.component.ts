/***********************************************************************
 *									*
 * Exformatics Dynamic Search Angular Component				*
 *									*
 * Copyright (c) Exformatics.	All rights reserved.			*
 *									*																								*
 ***********************************************************************/

// dynamic-search.components
// Change log
// Date		User	Description
// ==========	====	=================================================================
// 25/10/2017 sak   Setup component
// 25/10/2017 sak   Adding Models in ../../models/AdvSearchParams.ts

import {
  Component,
  OnInit,
  Input,
  Injector
} from '@angular/core';
import {
  Http,
  Response,
  URLSearchParams
} from '@angular/http';

import {
  ReactiveFormsModule,
  FormBuilder
} from '@angular/forms';
import {

  WebpartComponent
} from '../../common';
import {
  DLCMSView
} from '../../common/models';

import {
  WidgetMenuComponent
} from '../../shared/widget-menu';
import {
  HelperService
} from '../../common/Helpers';
import {
  DsSearchParams,
  DsCoreObjects,
  DsSearchPagingParams
} from './type/search-store';

import {
  DataComponentBase
} from '@shared/data-component-base';

@Component({
  selector: 'app-dynamic-search',
  templateUrl: './dynamic-search.component.html',
  styleUrls: ['./dynamic-search.component.css']
})

export class DynamicSearchComponent extends DataComponentBase implements WebpartComponent, OnInit {

  @Input() data: DLCMSView;


  public entityData: any;

  errorMessage: any;
  public widgetActions: any[] = [];
  private hasWidgetMenu: boolean;
  public isDataLoaded: boolean;

  randomText: string;
  public nodata: string;


  // interface DSCoreObjects//
  Ds_ArrSettings: any[];
  //////
  // class DsSearchPagingParams//
  public dsSearchPaging: DsSearchPagingParams
  ////////
  // interface DSSearchParams//
  public dsSearchParams: DsSearchParams;
  //////

  constructor(private _fb: FormBuilder,
    injector: Injector) {
    super(injector)
    this.dsSearchPaging = new DsSearchPagingParams();
  }

  ngOnInit() {
    // this.loadData();
    this.populateParams();
  }

  populateParams = () => {
    this.dsSearchParams.Ds_Entity = this.getParameterByNameNUrl('DLEntity');
    this.dsSearchParams.Ds_SearchParameters = this.getParameterByNameNUrl('SearchParameters');
    this.dsSearchParams.Ds_DisplayParameters = this.getParameterByNameNUrl('DisplayParameters');
    this.dsSearchParams.Ds_PickFields = this.getParameterByNameNUrl('PickFields');
    this.dsSearchParams.Ds_OrderBy = this.getParameterByNameNUrl('OrderBy');
    this.dsSearchParams.Ds_Where = this.getParameterByNameNUrl('Where');
    this.dsSearchParams.Ds_SearchOnLoad = (this.getParameterByNameNUrl('SearchOnLoad') === 'true');
    this.dsSearchParams.Ds_Save = (this.getParameterByNameNUrl('Save') === 'true');
    this.dsSearchParams.Ds_ClickAction = this.getParameterByNameNUrl('ClickAction');
    this.dsSearchParams.Ds_Pick = this.getParameterByNameNUrl('Pick');
    this.dsSearchParams.Ds_Rows = this.getParameterByNameNUrl('Rows');

    this.populateSearchPagingParams();
  }

  populateSearchPagingParams = () => {
    if (this.dsSearchParams.Ds_Rows !== '') {
      if (this.dsSearchParams.Ds_Rows === 'All') {
        this.dsSearchPaging.Ds_RowsPerPage = 1000;
        this.dsSearchPaging.Ds_DisplayRowPicker = 0;
      } else {
        this.dsSearchPaging.Ds_RowsPerPage = parseInt(this.dsSearchParams.Ds_Rows, 10);
      }
    }
  }

  getParameterByNameNUrl = (name: string) => {
    return this.helperService.getParameterByName(name, this.data.DL_DynamicSearchParams);
  }
  EXDSDoReset() {

  }

  loadData = () => {
    this.isDataLoaded = true;
    this.dataEntityService.getEntityData(this.data)
      .subscribe(d => {
        if (d) {
          this.isDataLoaded = true;
          this.entityData = d;
        }
      },
      err => {
        console.log(`${this.data.DL_WebPart} => ${err}`);
      },
      () => {
        if (!this.entityData.length) {
          this.nodata = `Der er ingen ${this.data.DL_WebPart}`;
        }
      });

  }
}
