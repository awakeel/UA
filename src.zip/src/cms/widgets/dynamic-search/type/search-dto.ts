export interface DsSettingsDto {
    Entity: string;
    DisplayParams: any[];
    OrderByParams: string;
    XPathValue: string;
    XPathId: string;
}
