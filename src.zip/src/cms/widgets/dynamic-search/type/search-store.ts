
export class DsSearchPagingParams {
    Ds_DisplayRowPicker = 3; // 0 == show not, 1 = show, 2 = all, 3 = number, 4 = all + number
    Ds_SearchType  = 1; // 0=standard, 1=Google
    Ds_RowsPerPage  = 15; // Number of rows per page result
}

export interface DsCoreObjects {
    Ds_ArrSettings: any[];
    Ds_ArrSearchParameters: any[];
    Ds_ArrDisplayParameters: any[];
}

export interface DsSearchParams {
    Ds_Entity: string;
    Ds_SearchParameters: string;
    Ds_DisplayParameters: string;
    Ds_PickFields: string;
    Ds_OrderBy: string;
    Ds_Where: string;
    Ds_SearchOnLoad: boolean;
    Ds_Save: boolean;
    Ds_ClickAction: string;
    Ds_Pick: string;
    Ds_Rows: string;
}


