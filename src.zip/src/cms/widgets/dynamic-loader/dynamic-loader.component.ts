﻿import {
  Component, OnInit, Input, AfterViewInit,
  ViewChild, ComponentFactoryResolver, OnDestroy, ViewContainerRef, ComponentRef
} from '@angular/core';
import { WebpartComponent, Widget } from '../../common';


@Component({
  selector: 'app-dynamic-loader',
  templateUrl: './dynamic-loader.component.html',
  styleUrls: ['./dynamic-loader.component.css']

})
export class DynamicLoaderComponent implements AfterViewInit, OnDestroy {

  @Input() _widget: Widget;

  @ViewChild('dynamicWebPart', { read: ViewContainerRef }) webpartContainer: ViewContainerRef;

  constructor(
    private componentFactoryResolver: ComponentFactoryResolver) {

  }

  ngAfterViewInit() {
    setTimeout(_ => this.loadComponent(), 100);

  }

  loadComponent() {

    this.webpartContainer.clear();

    const componentFactory = this.componentFactoryResolver.resolveComponentFactory(this._widget.component);
    const componentRef = this.webpartContainer.createComponent(componentFactory);

    (<WebpartComponent>componentRef.instance).data = this._widget.data;
    componentRef.changeDetectorRef.detectChanges();
    componentRef.onDestroy(() => {
       componentRef.changeDetectorRef.detach();
    });

  }
  ngOnDestroy() {

  }

}
