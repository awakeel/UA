﻿import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule, Routes } from '@angular/router';
import { DynamicPageComponent } from './dynamic-page';
import { WidgetsComponent } from './widgets.component'

const routes: Routes = [
    {
        path: '', component: WidgetsComponent,
        children: [
            { path: 'pages', component: DynamicPageComponent },
            { path: ':page', component: DynamicPageComponent },
            { path: ':page/:entityId?/:entityName?', component: DynamicPageComponent },
        ]
    },
    // { path: '', redirectTo: '/pages', pathMatch: 'full' },


];

@NgModule({
    imports: [RouterModule.forChild(routes)],
    exports: [RouterModule]
})
export class WidgetRoutingModule { }
