export * from './dynamic-detail.component';

