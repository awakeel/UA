import { Component, Input, OnInit, OnDestroy, Injector, ViewChild } from '@angular/core';
import { Http, URLSearchParams } from '@angular/http';
import { Router, ActivatedRoute, RouterState } from '@angular/router';
// import { DomSanitizer } from '@angular/platform-browser';
import { DynamicIframeComponent } from '../dynamic-iframe';
import { WidgetMenuComponent } from 'cms/shared/widget-menu';

import { Observable, Subject } from 'rxjs/Rx';
import '../../common/rxjs-extensions';
import { WebpartComponent } from '../../common';

import { DLCMSView } from '../../common/models';
import { DataComponentBase } from '@shared/data-component-base';

@Component({
  selector: 'app-dynamic-detail',
  templateUrl: './dynamic-detail.component.html',
  styleUrls: ['./dynamic-detail.component.css']
})
export class DynamicDetailComponent extends DataComponentBase implements WebpartComponent, OnInit, OnDestroy {

  @Input() data: any;

  entityData: any[] = [];
  menuData: any[] = [];

  menuDataLoaded: boolean;

  private ngUnsub: Subject<any> = new Subject();
  constructor(private router: Router,
    injector: Injector, private route: ActivatedRoute
  ) {
    super(injector);

  }
  ngOnInit() {
    this.entityData = [];
    this.loadData();
    this.loadMenuData();
    // this.hasWidgetMenu = this.data['DL_RelatedActions'] !== undefined
  }
  ngOnDestroy() {
    this.ngUnsub.next();
    this.ngUnsub.unsubscribe();
  }

  public loadData() {
    this.entityData = [];

    const obsComb = Observable.combineLatest(this.route.params, this.route.queryParams,
      (params, qparams) => ({ params, qparams }));

    obsComb.subscribe(ap => {

      this.dataEntityService.getEntityData(this.data, null,ap.params['page'], ap.qparams['entityId'], ap.qparams['entityName'])
        .takeUntil(this.ngUnsub)
        .subscribe(d => {
          if (d) {
            this.entityData.push(d);

          }
        },
        err => { this.notify.error(`${this.data.DL_WebPart} => ${err}`); },
        () => { if (!this.entityData.length) { } });
    });
  }
  onActionClick(event, id) {

    new Function(event)();
  }
  onMenuClick(event) {
    new Function(event)();
  }
  refresh() {

    this.loadData();
  }
  onButtonClick(event) {

    new Function(event)();
  }
  loadMenuData() {

    this.dataEntityService.getMenuData(this.data)
      .takeUntil(this.ngUnsub)
      .subscribe(d => {
        if (d && d['DL_PageWidgetId'] === this.data.DL_PageWidgetId) {
          this.menuData.push(d);
          this.menuDataLoaded = true;
        }
      },
      err => this.notify.error(`${this.data.DL_WebPart} => ${err}`));
  }
  isArray = (data) => {
    return (Object.prototype.toString.call(data) === '[object Array]');
  }

  filterByMenuType = (type) => {

    if (type !== undefined && type) {
      if (this.menuData) {
        return this.menuData.filter(t => t.DL_Type == type);
      }
    }
  }
}
