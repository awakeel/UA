﻿import { Component, Injector, ViewEncapsulation, ViewContainerRef, AfterViewInit, OnDestroy } from '@angular/core';
import { ActivatedRoute, Route } from '@angular/router';

import { Observable } from 'rxjs/Rx';
import '../../common/rxjs-extensions';
import { AppConsts } from '@shared/AppConsts';
import { appModuleAnimation } from '@shared/animations/routerTransition';
import { DynamicListComponent } from '../dynamic-list';
import { DynamicFormComponent } from '../dynamic-form';
import { DynamicDetailComponent } from '../dynamic-detail';
import { DynamicIframeComponent } from '../dynamic-iframe';
import { OrganizationComponent } from '../organization';
import { UserProfileComponent } from '../userprofile';
import { PersonorganisationComponent } from '../personorganisation';
import { NameListComponent } from '../name-list';
import { SelectDetailComponent } from '../select-detail';
import { ActivityStreamComponent } from '../activity-stream';

import { DynamicActivityStreamComponent } from '../dynamic-activitystream';
import { DynamicWorkflowComponent } from '../dynamic-workflow';
import { Widget } from '../../common/webpart.item';
// import { AppComponentBase } from '@shared/app-component-base';
import { DataComponentBase } from '@shared/data-component-base';

@Component({
    selector: 'app-dynamic-page',
    templateUrl: './dynamic-page.component.html',
    styleUrls: ['./dynamic-page.component.css'],
    animations: [appModuleAnimation()]
})
export class DynamicPageComponent extends DataComponentBase implements AfterViewInit, OnDestroy {

    public widgets: Array<any> = [];

    thePage: any;
    sub: any;

    pageId: number;

    constructor(private injector: Injector,
        private route: ActivatedRoute
    ) {
        super(injector);
        this.pageId = 0;

    }

    filterByZone(zone: string) {

        return this.widgets
            .filter(w =>
                w.data.DL_Zone.toLowerCase() === zone);

    }

    ngAfterViewInit() {
        this.thePage = null;
        this.widgets = new Array();

        const obsComb = Observable
            .combineLatest(this.route.params, this.route.queryParams,
            (params, qparams) => ({ params, qparams }));

        obsComb.subscribe(ap => {
            if (ap.params['page']) {
                this.pageId = +ap.params['page'];
            }
            if ( this.pageId === 0 && ap.qparams['page']) {
                this.pageId = +ap.qparams['page'] || 1;
            }
            // console.log('current pageId', this.pageId);
            this.componentCatalogService
                .getWidgetsByPage(this.pageId)
                .map(d => {
                    return this.widgetFactory(d);
                })
                .subscribe((item) => {
                    if (item) {
                        // console.log('dynamicPage =>getWidgetsByPage', item);
                        if (item.data.DL_PageID === this.pageId.toString()
                        ) {
                            this.widgets.push(item);
                            this.thePage = item.data;
                        }
                    }
                }, err => { console.log('DynamicPage => error loading data'); },
                () => { console.log('Completed...') });
        });
    }
    widgetFactory = (d: any) => {

        let widget: any = null;
        if (d.DL_WebPartType) {
            switch (d.DL_WebPartType.trim().toLowerCase()) {
                case 'list':
                    widget = new Widget(DynamicListComponent, d);
                    break;
                case 'activitystream':
                    widget = new Widget(DynamicActivityStreamComponent, d);
                    break;
                case 'workflow':
                    widget = new Widget(DynamicWorkflowComponent, d);
                    break;
                case 'detail':
                    let componentName = '';

                    if (d.DL_ComponentName) {
                        componentName = d.DL_ComponentName.trim().toLowerCase();
                    }
                    if (componentName === 'app-dynamic-detail') {
                        widget = new Widget(DynamicDetailComponent, d);
                    }  else if (componentName === 'app-organization') {
                        widget = new Widget(OrganizationComponent, d);
                    } else if (componentName === 'dynamiciframewidget') {
                        widget = new Widget(DynamicIframeComponent, d);

                    } else if (componentName === 'app-personorganisation') {
                        widget = new Widget(PersonorganisationComponent, d);
                    } else if (componentName === 'app-name-list') {
                        widget = new Widget(NameListComponent, d);
                    } else if (componentName === 'app-select-list') {
                        widget = new Widget(SelectDetailComponent, d);
                    } else if (componentName === 'app-userprofile') {
                        widget = new Widget(UserProfileComponent, d);
                    } else if (componentName === 'app-activity-stream') {
                        console.log(d);
                        widget = new Widget(ActivityStreamComponent, d);
                    }
                    break;
                case 'form':
                    widget = new Widget(DynamicFormComponent, d);
                    break;
                default:
                    widget = new Widget(DynamicListComponent, d);
            }
            return widget;
        }
    }
    ngOnDestroy() {
        if (this.sub) {
            this.sub.unsubscribe();
        }
    }
}
