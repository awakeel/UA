﻿export * from './personorganisation.component';
