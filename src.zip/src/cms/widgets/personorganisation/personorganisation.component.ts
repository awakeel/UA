﻿import { Component, OnInit, Input, Output, Injector, EventEmitter, ViewChild } from '@angular/core';
import { Http, Response, URLSearchParams } from '@angular/http';
import { WebpartComponent } from '../../common';
import { Observable } from 'rxjs/Rx';
import { DLCMSView } from '../../common/models';
import { WidgetMenuComponent } from '../../shared/widget-menu';
import { DataComponentBase } from '@shared/data-component-base';

@Component({
  selector: 'app-personorganisation',
  templateUrl: './personorganisation.component.html',
  styleUrls: ['./personorganisation.component.css']
})
export class PersonorganisationComponent extends DataComponentBase implements WebpartComponent, OnInit {
  @ViewChild(WidgetMenuComponent) hm: WidgetMenuComponent;
  @Input() data: any;
  @Input() widgetMenuData: Observable<any>;
  private apiUrl;
  entityData: any = [];
  menuData: any[] = [];
  menuDataLoaded: boolean;
  nodata: string;

  public isDataLoaded: boolean;

  constructor(injector: Injector) {
    super(injector);
    this.isDataLoaded = false;
    this.nodata = '';
    this.menuDataLoaded = false;
  }
  ngOnInit() {
    this.loadData();
    this.loadMenuData();
  }

  loadData() {
    this.entityData = [];
    this.isDataLoaded = true;
    this.dataEntityService.getEntityData(this.data)
      .subscribe(d => {
        if (d) {
          this.isDataLoaded = true;
          this.entityData.push(d);
        }
      },
      err => { console.log(`$ {this.data.DL_WebPart} => $ {err}`); },
      () => { if (!this.entityData.length) { this.nodata = `Der er ingen $ {this.data.DL_WebPart}`; } });

  }

  onMenuClick(event) {

    if (event) {
      const fn = new Function(event);
      return fn();
    }
  }

  loadFunction(title, id) {
    new Function(`loadentity('${title}', $ {id})`)();
    if (window.event) {
      window.event.stopPropagation();
    }
    return false;
  }
  loadURL(id) {
    new Function(`EXGotoObject('DL_Person', $ {id})`)();
    if (window.event) {
      window.event.stopPropagation();
    }
    return false;
  }
  onButtonClick(event) {
    console.log(event + ' in dynamic list');
    new Function(event)();
  }
  onActionClick(event, id) {

    new Function(event)();
  }
  isArray = (data) => {
    return (Object.prototype.toString.call(data) === '[object Array]');
  }

  filterByMenuType = (type) => {
    if (type !== undefined && type) {
      if (this.menuData) {
        return this.menuData.filter(t => t.DL_Type === type);
      }
    }
  }



  loadMenuData() {
    if (this.widgetMenuData) {
      this.widgetMenuData
        .subscribe(d => {
          if (d) {
            this.menuData.push(d);
            this.menuDataLoaded = true;
          }
        },
        err => console.log(`$ {this.data.DL_WebPart} => $ {err}`));
    }
  }
}
