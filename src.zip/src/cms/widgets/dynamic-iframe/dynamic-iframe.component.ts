﻿import { DataComponentBase } from '@shared/data-component-base';
import { Component, OnInit, Injector, Input } from '@angular/core';
import { DomSanitizer } from '@angular/platform-browser';
import { WebpartComponent, Widget } from '../../common';
import { HelperService } from '../../common/helpers';


@Component({
    selector: 'app-dynamic-iframe',
    templateUrl: './dynamic-iframe.component.html',
    styleUrls: ['./dynamic-iframe.component.css']
})
export class DynamicIframeComponent extends DataComponentBase implements WebpartComponent, OnInit {

    @Input() data: any;


    private helper: HelperService;

    constructor(injector: Injector) {
        super(injector);
    }


    ngOnInit() {
        const id = this.helperService.getParameterByName(this.data.DL_Page);
        const that = this;

        if (!id) {
            setTimeout(function () { new Function("EXLoadQuickSearch('" + that.data.DL_Page + "',false, null, null, null, true)")() }, 500);
        } else {
            setTimeout(function () { new Function("displayentity('" + that.data.DL_Page + "'," + id + ")")() }, 500);
        }


    }

}
