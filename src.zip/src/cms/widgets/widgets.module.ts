﻿
import { NgModule, ModuleWithProviders } from '@angular/core';
import { CommonModule } from '@angular/common';
import { HttpModule } from '@angular/http';
import {HttpClientModule, HttpClientJsonpModule} from '@angular/common/http';
import { NgbModule, NgbDropdownModule } from '@ng-bootstrap/ng-bootstrap';
import {FormsModule, ReactiveFormsModule} from '@angular/forms';
import { MomentModule } from 'angular2-moment';
import { AbpModule } from '@abp/abp.module';
import { ServiceProxyModule } from '@shared/service-proxies/service-proxy.module';
import { SharedModule } from '@shared/shared.module';
import { RouteReuseStrategy } from '@angular/router';
import { CustomRouteReuseStrategy } from 'cms/shared/route-reuse-strategy';

import { WidgetRoutingModule } from './widget-routing.module';
import { DynamicLoaderComponent } from './dynamic-loader';
import { DynamicListComponent } from './dynamic-list';
import { DynamicDetailComponent } from './dynamic-detail';
import { DynamicFormComponent } from './dynamic-form';
import { OrganizationComponent } from './organization';
import { UserProfileComponent } from './userprofile';
import { DynamicIframeComponent } from './dynamic-iframe';
import { DynamicPageComponent } from './dynamic-page';

import { PersonorganisationComponent } from './personorganisation';
import { MetadataService } from '../common/metadata.service';
import { DataEntityService} from '../common/data-entity.service';
import { HelperService } from '../common/helpers';
import { SafeUrlPipe, ExtractNameFromADUserNamePipe } from '../shared';
import { TruncateModule } from '../shared/truncate';
import { WidgetMenuComponent } from '../shared/widget-menu';
import { NameListComponent } from './name-list';
import { SelectDetailComponent } from './select-detail';
import { SearchResultsComponent } from './dynamic-search/search-results/search-results.component';


import { DynamicSearchComponent } from './dynamic-search/dynamic-search.component';

import { SearchFormComponent } from './dynamic-search/search-form/search-form.component';
import { WidgetsComponent } from './widgets.component';
import { TopbarModule } from 'cms/shared/topbar/topbar.module';
import { ActivityStreamComponent } from 'cms/widgets/activity-stream/activity-stream.component';
import { CommentEditorComponent } from 'cms/widgets/activity-stream/comments/comment-editor';
import { CommentSingleComponent } from 'cms/widgets/activity-stream/comments/comment-single';
import { CommentsComponent } from 'cms/widgets/activity-stream/comments/comments.component';
import { DynamicActivityStreamComponent } from 'cms/widgets/dynamic-activitystream';
import { DynamicWorkflowComponent } from 'cms/widgets/dynamic-workflow';


@NgModule({
  imports: [
    CommonModule,
    HttpModule,
    HttpClientModule,
    HttpClientJsonpModule,
    NgbModule,
    FormsModule,
    MomentModule,
    ReactiveFormsModule,
    TruncateModule,
    WidgetRoutingModule,
    NgbDropdownModule.forRoot(),
    AbpModule,
    ServiceProxyModule,
    SharedModule.forRoot(),
    TopbarModule
  ],

  declarations: [

    DynamicPageComponent,
    DynamicLoaderComponent,
    DynamicListComponent,
    DynamicDetailComponent,
    DynamicFormComponent,
    OrganizationComponent,
    DynamicIframeComponent,
    PersonorganisationComponent,
    SafeUrlPipe,
    ExtractNameFromADUserNamePipe,
    WidgetMenuComponent,
    NameListComponent,
    SelectDetailComponent,
    WidgetsComponent,
    UserProfileComponent,

    CommentsComponent,
    CommentEditorComponent,
    CommentSingleComponent,
    ActivityStreamComponent,
    DynamicSearchComponent,
    SearchFormComponent,
    SearchResultsComponent,
    DynamicActivityStreamComponent,
    DynamicWorkflowComponent
  ],

  exports: [

    WidgetMenuComponent,
    DynamicPageComponent,
    DynamicLoaderComponent,
    DynamicListComponent,
    DynamicDetailComponent,
    DynamicFormComponent,
    OrganizationComponent,
    DynamicIframeComponent,
    PersonorganisationComponent,
    NameListComponent,
    SelectDetailComponent,
    UserProfileComponent,
    CommentsComponent,
    CommentEditorComponent,
    CommentSingleComponent,
    ActivityStreamComponent,
    DynamicSearchComponent,
    SearchFormComponent,
    SearchResultsComponent,
    DynamicActivityStreamComponent,
    DynamicWorkflowComponent,
    WidgetMenuComponent,
    WidgetsComponent
  ],
  entryComponents: [
    DynamicPageComponent,
    DynamicLoaderComponent,
    DynamicListComponent,
    DynamicDetailComponent,
    DynamicFormComponent,
    OrganizationComponent,
    DynamicIframeComponent,
    PersonorganisationComponent,
    NameListComponent,
    SelectDetailComponent,
    UserProfileComponent,
    ActivityStreamComponent,
    DynamicSearchComponent,
    DynamicWorkflowComponent
  ]
  // ,
  // providers:  [MetadataService,
  //   DataEntityService, HelperService,
  //   { provide: RouteReuseStrategy, useClass: CustomRouteReuseStrategy }]
})
export class WidgetsModule {
  static forRoot(): ModuleWithProviders {
    return {
      ngModule: WidgetsModule,
      providers: [MetadataService,
        DataEntityService, HelperService,
        { provide: RouteReuseStrategy, useClass: CustomRouteReuseStrategy }],
    }
  }
}
