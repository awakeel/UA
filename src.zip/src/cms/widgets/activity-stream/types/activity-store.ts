interface RootObject {
  DL_ENTITYDATA: DLENTITYDATA;
}

interface DLENTITYDATA {
  Root: Root;
}

interface Root {
  Exformation: Exformation[];
  Childs: Child[];
  Likers: Liker[];
  CurrentUser: CurrentUser;
}

interface CurrentUser {
  DL_FullName: string;
  DL_URLImage?: any;
  DL_ID: string;
}

interface Liker {
  DL_Id: string;
  DL_Name: string;
  DL_URLImage?: any;
  DL_Created: string;
  DL_sAMaccountnameForeign: string;
  DL_ProfileParent: string;
}

interface Child {
  DL_ProfileParent: string;
  DL_Id: string;
  DL_Created: string;
  DL_UserId: string;
  DL_FullName: string;
  ProfileImage?: any;
  DL_Name: string;
  DL_URLImage?: any;
  DL_Description: string;
  DL_URLDocument?: any;
  DL_sAMAccountNameForeign: string;
  DL_LastModified: string;
  DL_Location?: any;
  DL_Latitude?: any;
  DL_Longitude?: any;
  LikesCount: string;
  SubCommentsCount: string;
}

interface Exformation {
  DL_Id: string;
  DL_Created: string;
  DL_UserId: string;
  DL_FullName: string;
  ProfileImage?: any;
  DL_Name: string;
  DL_URLImage?: any;
  DL_Description: string;
  DL_URLDocument?: any;
  DL_sAMAccountNameForeign: string;
  DL_EntityId?: string;
  DL_EntityNameForeign?: any;
  DL_LastModified: string;
  DL_Location?: any;
  DL_Latitude?: any;
  DL_Longitude?: any;
  DL_EntityDescription?: any;
  DL_CaseTitle?: any;
  DL_CaseNo?: any;
  LikesCount: string;
  SubCommentsCount: string;
}
