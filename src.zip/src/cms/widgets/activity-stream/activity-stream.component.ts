﻿
import { Component, OnInit, OnDestroy, Input, Output, EventEmitter, Injector, ViewChild, Pipe } from '@angular/core';

import { FormGroup, FormControl, FormBuilder, Validators } from '@angular/forms';

import { Observable, Subject } from 'rxjs/Rx';
import '../../common/rxjs-extensions';

import { WebpartComponent } from '../../common';
import { DLCMSView } from 'cms/common/models';

import { WidgetMenuComponent } from 'cms/shared/widget-menu';
import { environment } from '../../../environments/environment';
import { DataComponentBase } from 'shared/data-component-base';

@Component({
  selector: 'app-activity-stream',
  templateUrl: './activity-stream.component.html',
  styleUrls: ['./activity-stream.component.css'],

})


export class ActivityStreamComponent extends DataComponentBase implements WebpartComponent, OnInit, OnDestroy {
  @Input() data: any;


  public submitted: boolean; // keep track on whether form is submitted
  public events: any[] = []; // use later to display form changes

  public entityData: any[] = [];
  public likersData: any[] = [];
  public childsData: any[] = [];
  public userData: any[] = [];

  public exformationData: any[];
  errorMessage: any;
  public widgetActions: any[] = [];
  private hasWidgetMenu: boolean;
  public isDataLoaded: boolean;
  public dataObject: any;

  menuData: any[] = [];
  menuDataLoaded: boolean;
  randomText: string;
  public nodata: string;

  private ngUnsub: Subject<any> = new Subject();

  constructor(injector: Injector, private _fb: FormBuilder) {
    super(injector);
  }
  // exformations: Exformation[];
  ngOnInit() {

    this.entityData = [];
    this.loadData();
    // this.loadLikesData();
    // this.loadChildData();
    // this.loadUserData();


    // this.loadMenuData();
  }

  ngOnDestroy() {
    this.ngUnsub.next();
    this.ngUnsub.unsubscribe();
  }

  saveComment($event) {

    this.dataEntityService
      .createService('api/activities/comments', $event)
      .subscribe(
      result => console.log(result),
      error => this.errorMessage = <any>error
      );
  }

  public loadData() {
    this.entityData = [];
    this.isDataLoaded = true;
    this.dataEntityService.getEntityData(this.data, 'activityStreamData')
      .subscribe(d => {
        if (d) {
          this.dataObject = d;
          this.isDataLoaded = true;
          if (d.Exformation) {
            this.exformationData = d.Exformation;
          }
          if (d.Likers) {
            this.likersData = d.Likers;
          }
          if (d.Childs) {
            this.childsData = d.Childs;
          }
          if (d.CurrentUser) {
            this.userData = d.CurrentUser;
          }
          this.entityData.push(d);
        }
      },
      err => { this.notify.error(`${this.data.DL_WebPart} => ${err}`); },
      () => { if (!this.entityData.length) { this.nodata = `Der er ingen ${this.data.DL_WebPart}`; } });

  }

  public submitComment(elem, EntityObj?) {
    if (!elem.form.classList.contains('disabled')) {
      elem.form.classList.add('disabled');
      let inputText = elem.value;

      if (elem.form.getElementsByClassName('uploadedImgName')[0].value !== '') {
        inputText = '<img src="' + elem.form.getElementsByClassName("uploadedImgName")[0].value + '" />' + inputText;
      }
      elem.form.querySelectorAll("input[name=DL_Description]")[0].setAttribute("value", inputText);
    }
    /*
    alert('tese');

    let endPoint = '/dl_exformation';

    let comment = {"DL_Description":"live com","DL_EntityNameForeign":null,"DL_EntityId":"0"};

    this.dataEntityService
    .addComment(comment, endPoint)
    .subscribe((res) =>{
        console.log(res);
    }, ((err) =>{
        console.log(err);
    })
    ) */

    return false;

    //     var currentForm = $(form);

    //     // disable it until comment is posted to avoid intermediate events
    //     if (!currentForm.hasClass('disabled')) {
    //         currentForm.addClass('disabled');
    //         replaceMentionsHtml(form);

    //         var inputText = currentForm.find('input[name=DL_Description]').val();

    //         if (currentForm.find('.uploadedImgName').val() != "") {
    //             inputText = '<img src="' + currentForm.find('.uploadedImgName').val() + '" />' + inputText;
    //         }

    //         currentForm.find('input[name=DL_Description]').val(inputText);
    //         console.log(form.serializeObject());
    //         $.ajax({
    //             beforeSend: function () {
    //                 currentForm.find('input[type=submit]').attr('disabled', 'disabled');
    //             },
    //             url: '/ex_sqlSvc/REST/Service.svc/Entity/dl_exformation',
    //             type: 'POST',
    //             data: form.serializeObject(),
    //             //contentType: 'application/json; charset=utf-8',
    //             dataType: 'json',
    //             success: function (x3d) {
    //                 x3d = x3d.DL_ENTITYDATA.dl_exformation;
    //                 $('#mainComment').attr('rows', 1);
    //                 $('.mainCommentContainer').removeClass('mainCommentContainerFocused');

    //                 //var imgFile = '';
    //                 //if (x3d.SnapUrl != null) {

    //                 //    imgFile = '<img class="commentImage" src="/Images/ActivityStream/' + x3d.SnapUrl + '"  onerror="this.src = \'/EX_Resources/gif/48x48/ajax-loader.gif\';"/>';
    //                 //}
    //                 var msg = '';
    //                 if (x3d.DL_Description != null) {
    //                     msg = x3d.DL_Description;
    //                 }
    //                 var commentHtml = '<div class="parentComment"><div class="userInfo activityOwner"><a href="#" class="userThumb notClickable">';
    //                 commentHtml += '<img src="' + currentUserImageG + '"></a><a href=" #" class="showOwnerProfilePreview notClickable">' + currentUserNameG + '</a><br/><span id="' + x3d.DL_LastModified.replace('T', ' ') + '" class="mainCommentTime liveTime">Just now</span><span class="mainCommentModifiedTime">' + x3d.DL_LastModified.replace('T', ' ') + '</span></div>';
    //                 //commentHtml += '<div class="clear"></div><div class="activityMain"><table class="commentTbl"><tbody><tr><td>' + imgFile + '</td></tr>';
    //                 commentHtml += '<tr><td><div class="activityMain mainCommentMessage">' + convertMentions(msg) + '</div></td></tr></tbody></table><div class="clear"></div></div></div>';


    //                 // clear values after comment is submitted
    //                 $('#mainComment').val("");
    //                 $('#mainCommentControls img').attr('src', '');
    //                 currentForm.children().find('.mentions').html("<div></div>");
    //                 currentForm.children().find('.mainComment').height(20);
    //                 currentForm.get(0).reset();
    //                 currentForm.find('.uploadedImgName').val("");

    //                 var commentOptions = $('.template.commentOptionsTemplate').html() + $('.template.childFormTemplate').html();
    //                 $('<div data-comment-id="' + x3d.DL_Id + '" class="passive-content">' + commentOptions + '</div>')
    //                     .prependTo('#completeStream').children('.commentSection').find('.parentCommentId').val(x3d.DL_Id);

    //                 $('#completeStream').prepend(commentHtml);
    //                 $('#completeStream').children().not('.singleComment').wrapAll('<div class="singleComment"></div>');
    //                 currentForm.removeClass('disabled');
    //             },
    //             complete: function () {
    //                 bindMentionInput();
    //                 currentForm.find('input[type=submit]').removeAttr('disabled');
    //                 $('body').focus(); // leave focus from comment textbox
    //                 currentForm.children().find('.mainComment').blur();
    //             },
    //             error: function (xhr) {
    //                 //alert('Sorry, ');

    //             }
    //         });
    //     }
  }



  public ExecuteUnLike(commentID, EntityObj?: any) {
    console.log(commentID);
  }

  public likeCommentDetail(commentID, likers: any[], userData) {
    // check if current user has liked the comment
    let likedUserNames = '';
    let currentUserLikes = false;
    let likedUserCount = 0;
    if (likers) {
      // Likers = Likers; // because each loop does not work if object is not in an array
      likers.forEach((l) => {
        if (l.DL_ProfileParent === commentID) {
          if (l.DL_Name === userData.DL_FullName) {
            // $commentOptionsHtml.find('.parentCommentLike').attr('data-likeid', Likers[k].DL_Id);
            // $commentOptionsHtml.find('.parentCommentLike').text('Unlike');
            // $commentOptionsHtml.find('.parentCommentLike').addClass('liked');
            currentUserLikes = true;
          } else {
            likedUserNames += l.DL_Name + ', ';
          }
          likedUserCount++;
        }
      });

    }

    if (likedUserCount > 0) {
      likedUserNames = likedUserNames.replace(/,([^,]*)$/, '$1'); // remove last comma
      if (currentUserLikes) {
        if (likedUserNames === '') {
          likedUserNames = 'You like this.';
        } else if (likedUserCount > 3) {
          // $commentOptionsHtml.find('.allLikeNames').html(likedUserNames);
          likedUserCount--; // because 1 is You
          likedUserNames = 'You and <a href="#" class="showLikedUsers">' + likedUserCount + " others</a> like this."
        } else if (likedUserCount === 2) {
          likedUserNames = 'You and ' + likedUserNames + 'like this.';
        } else {
          likedUserNames = 'You, ' + likedUserNames + 'like this.';
        }
      } else {
        if (likedUserCount > 3) {
          // $commentOptionsHtml.find('.allLikeNames').html(likedUserNames);
          likedUserNames = '<a href="#" class="showLikedUsers">' + likedUserCount + " people</a> like this.";
        } else if (likedUserCount === 1) {
          likedUserNames = likedUserNames + 'likes this.';
        } else {
          likedUserNames = likedUserNames + 'like this.';
        }
      }

      return likedUserNames;
    }
  }

  // public loadLikesData() {
  //     this.entityData = [];
  //     this.isDataLoaded = true;
  //     this.dataEntityService.getEntityDataByProc(this.data,'Likers')
  //         .subscribe(d => {
  //             if (d) {
  //                 this.isDataLoaded = true;
  //                 this.likesData.push(d);
  //             }
  //         },
  //         err => { console.log(`${this.data.DL_WebPart} => ${err}`); },
  //         () => { if (!this.likesData.length) { this.nodata = `Der er ingen ${this.data.DL_WebPart}`;} });

  // }
  // public loadChildData() {
  //     this.entityData = [];
  //     this.isDataLoaded = true;
  //     this.dataEntityService.getEntityDataByProc(this.data,'Childs')
  //         .subscribe(d => {
  //             if (d) {
  //                 this.isDataLoaded = true;
  //                 this.childData.push(d);
  //             }
  //         },
  //         err => { console.log(`${this.data.DL_WebPart} => ${err}`); },
  //         () => { if (!this.childData.length) { this.nodata = `Der er ingen ${this.data.DL_WebPart}`;} });

  // }

  // public loadUserData() {
  //     this.entityData = [];
  //     this.isDataLoaded = true;
  //     this.dataEntityService.getEntityDataByProc(this.data,'CurrentUser')
  //         .subscribe(d => {
  //             if (d) {
  //                 this.isDataLoaded = true;
  //                 this.userData.push(d);
  //             }
  //         },
  //         err => { console.log(`${this.data.DL_WebPart} => ${err}`); },
  //         () => { if (!this.userData.length) { this.nodata = `Der er ingen ${this.data.DL_WebPart}`;} });

  // }
  save(val) {
    console.log(val);
    this.submitted = true; // set form submit to true

    this.dataEntityService
      .createService('api/Movie/TestPost', val)
      .subscribe(
      result => console.log(result),
      error => this.errorMessage = <any>error
      );


  }
  updateComment($event) {

    //this.exformationData = $event;
    console.log('updateComment', $event);
    let a = $event.splice(0, 1)[0];

    console.log(a);

    this.dataObject.Exformation.splice(0, 0, a);
    console.log('updated objext', this.dataObject.Exformation);

  }

  updateSubComment($event) {

    //this.exformationData = $event;
    console.log('update sub Comment', $event);
    let a = $event.splice(0, 1)[0];

    console.log(a);

    this.dataObject.Childs.splice(0, 0, a);
    console.log('updated objext', this.dataObject.Childs);

  }

}

//export class ActivityStreamComponent implements  OnInit {
   // @ViewChild(WidgetMenuComponent) hm: WidgetMenuComponent;
  //@Input() data: any
 // private apiUrl;
 // entityData: any = [];


  //public isDataLoaded: boolean;
  //private dataEntityService: DataEntityService;
 // menuData: any[] = [];
 // menuDataLoaded: boolean;
 // constructor() {
    //this.isDataLoaded = false;
  //  this.menuDataLoaded = false;
 // }
 // ngOnInit() {
      //console.log('activity-stream is loaded');
     // this.loadData();
      //this.loadMenuData();

 // }
/*
  loadData() {
      this.isDataLoaded = true;
      this.entityData = [];
      this.dataEntityService.getEntityData(this.data)
          .subscribe(d => {
              this.entityData.push(d);
          },
          err => { console.log(`${this.data.DL_WebPart} => ${err}`); }),
          () => {  }
  }

  getParameterByName(name: any) {
      let url = window.location.href;
      name = name.replace(/[\[\]]/g, "\\$&");
      var regex = new RegExp("[?&]" + name + "(=([^&#]*)|&|#|$)"),
          results = regex.exec(url);
      if (!results) return null;
      if (!results[2]) return '';
      return decodeURIComponent(results[2].replace(/\+/g, " "));
  }
  loadFunction(id) {
      new Function("loadentity('DL_Organisation', "+id+")")();
  }
  setFunction(id, type, modified) {
      console.log(id);
      new Function("SetEntityItemValue('DL_Organisation', " + id + ",'" + modified +"', 'DL_Add'," + type + ")")();
      let that = this;
      setTimeout(function () {
          that.loadData();
      }, 300);
  }
  onMenuClick(event) {

    if (event) {
      const fn = new Function(event);
      return fn();
    }
  }
  onButtonClick(event) {
      console.log(event + ' in dynamic list');
      new Function(event)();
  }
  onActionClick(event, id) {
      //const k = event.replace('DL_Id', id);
      //if (k) {
      //    const fn = new Function(k);
      //    return fn();
      //}
      new Function(event)();
  }

  isArray = (data) => {
      return (Object.prototype.toString.call(data) === '[object Array]');
  }

  filterByMenuType = (type) => {
      //console.log(type);
      if (type !== undefined && type) {
          if (this.menuData)
              return this.menuData.filter(t => t.DL_Type == type);
      }
  }


  loadMenuData() {

      this.dataEntityService.getMenuData(this.data)
          //.filter(d =>
          // d['DL_PageWidgetId'] === this.config.DL_PageWidgetId  &&
          // d['DL_Type'] === 'row')
          .subscribe(d => {
              if (d && d['DL_PageWidgetId'] === this.data.DL_PageWidgetId) {
                  this.menuData.push(d);
                  this.menuDataLoaded = true;
              }
          },
          err => console.log(`${this.data.DL_WebPart} => ${err}`));
  }

*/

// }
