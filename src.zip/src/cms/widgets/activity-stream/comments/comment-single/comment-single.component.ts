import { Component, OnInit, Input, Output, EventEmitter, ViewChild, OnChanges } from '@angular/core';
import { CommentEditorComponent } from '../comment-editor';


@Component({
  selector: 'app-comment-single',
  templateUrl: './comment-single.component.html',
  styleUrls: ['./comment-single.component.css']

})
export class CommentSingleComponent implements OnInit, OnChanges {
  // The time of the comment as a timestamp
  @Input() commentData: any[];
  @Input() comments: any;
  @Input() dataObject: any;

  public Exformation: any[];
  public Childs: any[];
  public CurrentUser: any;
  public Likers: any[];
  public cssClass = '';
  // // The user object of the user who created the comment
  // @Input() user;
  // // The comment content
  // @Input() content;
  // If a comment was edited this event will be emitted
  @Output() commentEdited = new EventEmitter();
  @Output() subCommentsUpdated = new EventEmitter();
  // We are using an editor for adding new comments and control it
  // directly using a reference
  @ViewChild(CommentEditorComponent) commentEditorComponent;

  constructor() { }

  ngOnInit() {

    if (this.dataObject) {
      console.log(this.dataObject);
      this.Exformation = this.dataObject.Exformation;
      this.Childs = this.dataObject.Childs;
      this.CurrentUser = this.dataObject.CurrentUser;
      this.Likers = this.dataObject.Likers;
    }
    this.cssClass = 'childWrapper';
    // console.log("CurrentUser: " + this.dataObject.CurrentUser);
  }

  // We use input change tracking to prevent dealing with
  // undefined comment list
  ngOnChanges(changes) {
    if (changes.comments &&
      changes.comments.currentValue === undefined) {
      this.comments = [];
    }
  }

  addNewSubComment($event) {
    // lets update description field


    $event.DL_Description = $event.commentText;
    $event.DL_FullName = this.CurrentUser.DL_FullName;
    $event.DL_URLImage = this.CurrentUser.DL_URLImage;
    $event.DL_Created = new Date();
    // $event.DL_ProfileParent = '2';

    const comments = this.dataObject.Childs.slice();
    console.log(comments.length);

    comments.push($event);
    console.log("Sub com added. total comments: " + comments.length);


    // comments.splice(0, 0, {
    //   user: 'admin',
    //   time: +new Date(),
    //   content: $event.commentText //this.commentEditorComponent.getEditableContent()
    // });
    // Emit event so the updated comment list can be persisted
    // outside the component
    this.subCommentsUpdated.next(comments);
    // We reset the content of the editor
    this.commentEditorComponent.resetForm();
  }
  onContentSaved(content) {
    this.commentEdited.next(content);
  }
  public commentLikeText(commentID, Likers, CurrentUser) {
    let likedText = 'Like';
    if (Likers && Likers.length) {
      Likers.forEach((l) => {
        if (l.DL_ProfileParent === commentID && l.DL_Name === CurrentUser.DL_FullName) {
          likedText = 'Unlike';
        }
      });

    }
    return likedText;
  }

  public ExecuteUnLike(commentID, event) {
    console.log(commentID);
    var target = event.target || event.srcElement || event.currentTarget;
    var liked = (target.attributes.class.nodeValue.indexOf('currentUserLikes') > 0);

    if (!liked) {
      var likeData = {
        'DL_Name': this.CurrentUser.DL_FullName,
        'DL_URLImage': this.CurrentUser.DL_URLImage,
        'DL_ProfileParent': commentID
      };
      this.Likers.push(likeData);
      var newCount = parseInt((target.parentElement.getElementsByClassName('parentLikeCount')[0].innerHTML == '' ? 0 : target.parentElement.getElementsByClassName('parentLikeCount')[0].innerHTML)) + 1;
      target.parentElement.getElementsByClassName('parentLikeCount')[0].innerHTML = newCount;
      target.attributes.class.nodeValue = target.attributes.class.nodeValue + ' currentUserLikes';
      target.text = 'Unlike';
    } else {
      var newCount = parseInt((target.parentElement.getElementsByClassName('parentLikeCount')[0].innerHTML == '' ? 0 : target.parentElement.getElementsByClassName('parentLikeCount')[0].innerHTML)) - 1;
      target.parentElement.getElementsByClassName('parentLikeCount')[0].innerHTML = newCount;
      target.attributes.class.nodeValue = target.attributes.class.nodeValue.replace('currentUserLikes', '');
      target.text = 'Like';
    }
  }
  public ExecuteUnLikeChild(commentID, event) {
    console.log(commentID);
    var target = event.target || event.srcElement || event.currentTarget;
    var liked = (target.attributes.class.nodeValue.indexOf('currentUserLikes') > 0);

    if (!liked) {
      var likeData = {
        'DL_Name': this.CurrentUser.DL_FullName,
        'DL_URLImage': this.CurrentUser.DL_URLImage,
        'DL_ProfileParent': commentID
      };
      this.Likers.push(likeData);
      var newCount = parseInt(target.parentElement.getElementsByTagName('span')[0].innerHTML) + 1;
      target.parentElement.getElementsByTagName('span')[0].innerHTML = newCount;
      target.attributes.class.nodeValue = target.attributes.class.nodeValue + ' currentUserLikes';
      target.text = 'Unlike';
    } else {
      var newCount = parseInt(target.parentElement.getElementsByTagName('span')[0].innerHTML) - 1;
      target.parentElement.getElementsByTagName('span')[0].innerHTML = newCount;
      target.attributes.class.nodeValue = target.attributes.class.nodeValue.replace('currentUserLikes', '');
      target.text = 'Like';
    }


  }

}
