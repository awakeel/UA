import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { FormGroup, FormControl, FormBuilder, Validators } from '@angular/forms';


export interface Comment {
  commentText: string; // required with minimum 5 chracters
  DL_Description?: string;
  uploadedImgName: string;
  DL_EntityNameForeign: string;
  DL_EntityId: number;
  DL_ProfileParent: string;
}
@Component({
  selector: 'app-comment-editor',
  templateUrl: './comment-editor.component.html',
  styleUrls: ['./comment-editor.component.css']
})
export class CommentEditorComponent implements OnInit {

  @Input() showControls = false;
  @Input() editMode = false;
  @Input() content: any;
  @Input() CurrentUser: any;
  @Input() cssClass: any;
  @Output() commentPosted = new EventEmitter<any>();


  public DL_EntityId = '';
  public DL_Id = '';
  public DL_EntityNameForeign = '';
  public DL_Description = '';



  public commentData: any;
  public commentForm = new FormGroup({
    commentText: new FormControl(),
    DL_Description: new FormControl(),
    uploadedImgName: new FormControl(),
    DL_EntityNameForeign: new FormControl(),
    DL_EntityId: new FormControl(),
    DL_ProfileParent: new FormControl()
  });

  constructor(private _fb: FormBuilder) { }

  ngOnInit() {
    this.commentData = this.content;
    //this.cssClass = this.cssClass;
    //console.log('currentUser: ', this.currentUser);

    if (typeof (this.commentData) != 'undefined') {
      this.DL_EntityId = typeof (this.commentData.DL_EntityId) == 'undefined' ? '' : this.commentData.DL_EntityId;
      this.DL_Id = typeof (this.commentData.DL_Id) == 'undefined' ? '' : this.commentData.DL_Id;
      this.DL_Description = typeof (this.commentData.DL_Description) == 'undefined' ? '' : this.commentData.DL_Description;
      this.DL_EntityNameForeign = typeof (this.commentData.DL_EntityNameForeign) == 'undefined' ? '' : this.commentData.DL_EntityNameForeign;
    }
    this.commentForm = this._fb.group({
      commentText: ['', Validators.required],
      DL_Description: [this.DL_Description],
      uploadedImgName: new FormControl(),
      DL_EntityNameForeign: [this.DL_EntityNameForeign],
      DL_EntityId: [this.DL_EntityId],
      DL_ProfileParent: [this.DL_Id]
    });

  }

  save(obj: any) {
    this.commentPosted.next(obj);
    this.commentForm.reset();
    this.commentForm = this._fb.group({
      commentText: ['', Validators.required],
      DL_Description: [''],
      uploadedImgName: new FormControl(),
      DL_EntityNameForeign: new FormControl(),
      DL_EntityId: [this.DL_Id],
      DL_ProfileParent: [this.DL_Id]
    });
  }
  resetForm() {
    this.commentForm.reset();
  }
}


