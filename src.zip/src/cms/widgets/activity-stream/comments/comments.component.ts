import { Component, OnInit, Input, Output, EventEmitter, ViewChild, OnChanges } from '@angular/core';
import { CommentEditorComponent } from './comment-editor';
import { CommentSingleComponent } from './comment-single';

@Component({
  selector: 'app-comments',
  templateUrl: './comments.component.html',
  styleUrls: ['./comments.component.css']
})
export class CommentsComponent implements OnInit, OnChanges {
  @Input() comments: any;

  @Input() dataObject;
  public cssClass = '';
  public CurrentUser: any;

  // Event when the list of comments have been updated
  @Output() commentsUpdated = new EventEmitter();
  // We are using an editor for adding new comments and control it
  // directly using a reference
  @ViewChild(CommentEditorComponent) commentEditorComponent;


  public userComments: any[];

  constructor() { }

  ngOnInit() {
    console.log('component data ', this.dataObject);
    this.comments = [];

    if (this.dataObject) {
      if (this.dataObject.CurrentUser) {
        this.CurrentUser = this.dataObject.CurrentUser;
      }
      this.comments = this.dataObject;
    }
    this.cssClass = 'parentWrapper';
  }

  // We use input change tracking to prevent dealing with
  // undefined comment list
  ngOnChanges(changes) {
    if (changes.comments &&
      changes.comments.currentValue === undefined) {
      this.comments = [];
    }
  }

  // Adding a new comment from the newCommentContent field that is
  // bound to the editor content
  addNewComment($event) {
    // lets update description field


    $event.DL_Description = $event.commentText;
    // $event.DL_FullName = this.dataObject.CurrentUser.DL_FullName;
   // $event.DL_URLImage = this.dataObject.CurrentUser.DL_URLImage;
    $event.DL_Created = new Date();

    const comments = this.comments.Exformation.slice();
    console.log(comments.length);
    $event.DL_Id = Math.max.apply(Math, comments.map(function (o) { return o.DL_Id; })) + 1;

    comments.splice(0, 0, $event);
    console.log('total comments:', comments.length);


    // comments.splice(0, 0, {
    //   user: 'admin',
    //   time: +new Date(),
    //   content: $event.commentText //this.commentEditorComponent.getEditableContent()
    // });
    // Emit event so the updated comment list can be persisted
    // outside the component
    this.commentsUpdated.next(comments);
    // We reset the content of the editor
    this.commentEditorComponent.resetForm();
  }

  // This method deals with edited comments
  onCommentEdited(comment, content) {
    const comments = this.comments.Exformation.slice();
    // If the comment was edited with e zero length content, we
    // will delete the comment from the list
    if (content.length === 0) {
      comments.splice(comments.indexOf(comment), 1);
    } else {
      // Otherwise we're replacing the existing comment
      comments.splice(comments.indexOf(comment), 1, {
        user: comment.user,
        time: comment.time,
        content
      });
    }
    // Emit event so the updated comment list can be persisted
    // outside the component
    this.commentsUpdated.next(comments);
  }

  updateComment($event) {
    console.log('comment update', $event);
    // this.exformationData = $event;
    console.log('updateComment', $event);
    const a = $event.splice(0, 1)[0];

    console.log(a);

    this.dataObject.Exformation.splice(0, 0, a);

  }

  updateSubComment($event) {
    // console.log('update sub Comment',$event);
    const a = $event.slice(-1)[0];
    this.dataObject.Childs.push(a);
    // console.log('updated objext', this.dataObject.Childs);
  }

}
