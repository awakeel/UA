import { DynamicActivityStreamComponent } from 'cms/widgets/dynamic-activitystream';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';


describe('DynamicListComponent', () => {
  let component: DynamicActivityStreamComponent;
  let fixture: ComponentFixture<DynamicActivityStreamComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DynamicActivityStreamComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DynamicActivityStreamComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
