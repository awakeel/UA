﻿
import { Component, OnInit, Input, Output, Injector, OnDestroy, EventEmitter, ViewChild } from '@angular/core';
import { Http, Response, URLSearchParams } from '@angular/http';
import { WebpartComponent } from '../../common';
import { Observable, Subject } from 'rxjs/Rx';
import { DLCMSView } from '../../common/models';

import { WidgetMenuComponent } from 'cms/shared/widget-menu';
import { HelperService } from 'cms/common/helpers';
import { DataComponentBase } from '@shared/data-component-base';

@Component({
  selector: 'app-userprofile',
  templateUrl: './userprofile.component.html',
  styleUrls: ['./userprofile.component.css']
})
export class UserProfileComponent extends DataComponentBase implements WebpartComponent, OnInit, OnDestroy {
  @ViewChild(WidgetMenuComponent) hm: WidgetMenuComponent;
  @Input() data: any;

  @Input() widgetMenuData: Observable<any>;

  private apiUrl;
  entityData: any = [];


  public isDataLoaded: boolean;

  menuData: any[] = [];
  menuDataLoaded: boolean;
  nodata: string;

  private ngUnsub: Subject<any> = new Subject();

  public constructor(
    injector: Injector
  ) {
    super(injector);
    this.isDataLoaded = false;
    this.nodata = '';
    this.menuDataLoaded = false;
  }
  ngOnInit() {
    this.loadData();
    this.loadMenuData();
  }
  ngOnDestroy() {
    this.ngUnsub.next();
    this.ngUnsub.unsubscribe();
  }
  public loadData() {

    this.entityData = [];
    this.isDataLoaded = true;
    this.dataEntityService.getEntityData(this.data)
      .subscribe(d => {
        if (d) {
          this.isDataLoaded = true;
          this.entityData.push(d);
        }
      },
      err => { console.log(`$ {this.data.DL_WebPart} => $ {err}`); },
      () => { if (!this.entityData.length) { this.nodata = `Der er ingen $ {this.data.DL_WebPart}`; } });

  }


  loadFunction(id) {
    new Function()();
  }
  setFunction(id, type, modified) {
    console.log(id);
    new Function()();
    const that = this;
    setTimeout(function () {
      that.loadData();
    }, 300);
  }
  onMenuClick(event) {

    if (event) {
      const fn = new Function(event);
      return fn();
    }
  }
  onButtonClick(event) {

    new Function(event)();
  }
  onActionClick(event, id) {

    new Function(event)();
  }

  isArray = (data) => {
    return (Object.prototype.toString.call(data) === '[object Array]');
  }

  filterByMenuType = (type) => {
    if (type !== undefined && type) {
      if (this.menuData) {
        return this.menuData.filter(t => t.DL_Type === type);
      }
    }
  }


  loadMenuData() {
    if (this.widgetMenuData) {
      this.widgetMenuData
        .subscribe(d => {
          if (d) {
            this.menuData.push(d);
            this.menuDataLoaded = true;
          }
        },
        err => console.log(`$ {this.data.DL_WebPart} => $ {err}`));
    }
  }
}
