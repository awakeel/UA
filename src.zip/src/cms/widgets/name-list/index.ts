export * from './name-list.component';
