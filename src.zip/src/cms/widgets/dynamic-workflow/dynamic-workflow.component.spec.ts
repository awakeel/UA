import { async, ComponentFixture, TestBed } from '@angular/core/testing';


import { DynamicWorkflowComponent } from 'cms/widgets/dynamic-workflow';

describe('DynamicListComponent', () => {
  let component: DynamicWorkflowComponent;
  let fixture: ComponentFixture<DynamicWorkflowComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DynamicWorkflowComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DynamicWorkflowComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
