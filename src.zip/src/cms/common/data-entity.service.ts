﻿import { Injectable } from '@angular/core';
import { HttpClient, HttpEvent, HttpHandler, HttpInterceptor, HttpRequest } from '@angular/common/http';
import { Http, RequestOptions, Response, Headers } from '@angular/http';
import { Observable } from 'rxjs/Rx';
import './rxjs-extensions';
import { environment } from '../../environments/environment';

// http://exfor-test1/ex_sqlSvc/REST/Service.svc/Entity/DL_Activities//?Where=DL_ID=1&OrderBy=DL_Id


@Injectable()
export class DataEntityService {
    entityId: any;
    entityName: any;
    pageId: any;
    remoteAPI: string = environment.remoteAPI;
    headers: Headers;
    options: RequestOptions;
    constructor(private http: HttpClient) {
        this.headers = new Headers({
            'Content-Type': 'application/json',
            'Accept': 'q=0.8;application/json;q=0.9'
        });
        this.options = new RequestOptions({ headers: this.headers });
    }

    createService(url: string, param: any): Observable<any> {
        const body = JSON.stringify(param);
        return this.http
            .post(url, body)
            .map(this.extractData)
            .catch(this.handleError);
    }

    private extractData(res: Response) {
        const body = res.json();
        return body || {};
    }

    private handleError(error: any) {
        const errMsg = (error.message) ? error.message :
            error.status ? `${error.status} - ${error.statusText}` : 'Server error';
        console.error(errMsg);
        return Observable.throw(errMsg);
    }

    public getEntityDataByProc(data: any, dataSource?: string,
        page?: number, records?: number): Observable<any> {
        const apiUrl = this.buildDataUri(data);

        return this.http.get<any>(apiUrl)
            .map(res => res.json())
            .map(d => d.DL_ENTITYDATA)
            .map(d => d.Root);
    }
    public getEntityData(data, dataSource?: string,
        page?: number, entityId?: any, entityName?: any, tenant?: any,userEmail?:any, records?: number): Observable<any> {
        const apiUrl = this.buildDataUri(data, dataSource, page, entityId, entityName, tenant,userEmail);

        return this.http.get<any>(apiUrl)
        .map(res => res)
        .map(d => d.DL_ENTITYDATA)
        .flatMap(d => {
          if (d) {
            if (d[data.DL_View]) {
              return this.isArray(d[data.DL_View.trim()])
                ? d[data.DL_View.trim()] : [d[data.DL_View.trim()]];
            } else {
              return [d];
            }
          } else {
            return [];
          }

        });
      // .take(count)
      // .distinctUntilChanged();
    }


    buildAPIUrl = (config, ...args) => {
        let apiUrl: any;
        if (args && args.length) {
            if (args[1]) { // datasource
                apiUrl = `/public/assets/localData/${args[1]}.json`;
            } else {
                apiUrl = `/public/assets/localData/DL_CMSView.json`;
            }
            if (environment.local === true) {
                return apiUrl;
            }
            let where = config.DL_Where;

            if (where && args[4]) {// tenancy
                where = where.replace('%tenant%', args[4]);
            }
            if (where && args[2]) { // entityname, entityId
                where = where.replace('%' + args[3] + '%', args[2]);
            } 
            let orderBy = config.DL_OrderBy;
            if (!config.DL_OrderBy) {
                orderBy = '';
            }

            if (!config.DL_EntityType) {
                apiUrl = `${this.remoteAPI}dl_entity=${config.DL_View}&strWhere=${where}&strOrderBy=${orderBy}&date=`
                    + new Date().getTime();
            } else if (config.DL_EntityType && config.DL_EntityType.trim().toLowerCase() === 'procedure') {
                apiUrl = `${this.remoteAPI}sProcedure=${config.DL_View}&strWhere=${where}`;
            }

            return apiUrl;

        }
    }

    buildDataUri = (config,  dataSource?: any, page?: number, entityId?, entityName?, tenant?,userEmail?) => {
        console.log('dataSource', dataSource);
        let apiUrl: any
        if (dataSource) {
            apiUrl = `/public/assets/localData/${dataSource}.json`;
        } else {
            apiUrl = `/public/assets/localData/organisation.json`;
        }
        if (environment.local === true) {
            return apiUrl;
        }

        let where = config.DL_Where;

        if (where && tenant) {
            where = where.replace('%tenant%', tenant);
        }
        if (where && entityName) {
            where = where.replace('%' + entityName + '%', entityId);
        }
        if (where && userEmail) {
            where = where.replace('%user%', userEmail);
        }   
        let orderBy = config.DL_OrderBy;
        if (!config.DL_OrderBy) {
            orderBy = '';
        }

        if (!config.DL_EntityType) {
            apiUrl = `${this.remoteAPI}dl_entity=${config.DL_View}&strWhere=${where}&strOrderBy=${orderBy}&date=`
                + new Date().getTime();
        } else if (config.DL_EntityType && config.DL_EntityType.trim().toLowerCase() === 'procedure') {
            apiUrl = `${this.remoteAPI}sProcedure=${config.DL_View} ${where}`;
        }

        return apiUrl;

    }
    // DL_WidgetMenu
    buildActionUri = (config) => {

        let apiUrl = '/public/assets/localData/actionMenu.json';
        const where = ` DL_PageWidgetId=${config.DL_PageWidgetId}`;
        if (environment.local === false && environment.production === true) {
            apiUrl = `${this.remoteAPI}dl_entity=DL_WidgetMenu&strWhere=${where}&strOrderBy=DL_SequenceNo`;
        }
        return apiUrl;
    }
    public getMenuData(data) {
        const apiUrl = this.buildActionUri(data);
        const id = this.getParameterByName(data.DL_Page);

        return this.http.get<any>(apiUrl)
            .map(res => res)
            .map(d => d.DL_ENTITYDATA)
            .flatMap(d => {
                if (d && d['DL_WidgetMenu'] !== undefined) {
                    return this.isArray(d['DL_WidgetMenu'])
                        ? d['DL_WidgetMenu'] : [d['DL_WidgetMenu']];
                } else {
                    return [{ 'nodata': 'true' }];
                }
            })

    }


    public isArray = (data) => {
        return (Object.prototype.toString.call(data) === '[object Array]');
    }
    getParameterByName(name: any) {
        const url = window.location.href;
        name = name.replace(/[\[\]]/g, '\\$&');
        const regex = new RegExp('[?&]' + name + '(=([^&#]*)|&|#|$)'),
            results = regex.exec(url);
        if (!results) { return null; }
        if (!results[2]) { return ''; }
        return decodeURIComponent(results[2].replace(/\+/g, ' '));
    }

}
// @Injectable()
// export class CustomInterceptor implements HttpInterceptor {

//     intercept(req: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {
//         if (!req.headers.has('Content-Type')) {
//             req = req.clone({ headers: req.headers.set('Content-Type', 'application/json') });
//         }

//         req = req.clone({ headers: req.headers.set('Accept', 'application/json') });
//         console.log(JSON.stringify(req.headers));
//         return next.handle(req);
//     }
// }
