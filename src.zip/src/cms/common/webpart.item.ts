import { Observable } from 'rxjs/Rx';
import './rxjs-extensions';
import { Type } from '@angular/core';
import { DLCMSView } from './models';


export class Widget {
  constructor(
    public component: Type<any>,
    public data: DLCMSView,
    public menuData?: Observable<any>) { }
}
