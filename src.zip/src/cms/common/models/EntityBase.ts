import { DLCMSView } from './DLCMSView';
export interface DLENTITYDATA {
  DL_CMSView: DLCMSView[];
}


export interface EntityBase {
  DL_ENTITYDATA: DLENTITYDATA;
}
