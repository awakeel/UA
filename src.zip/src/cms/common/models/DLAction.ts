export class DLAction {
  DL_Id3: string;
  DL_Id: string;
  DL_CreatedBy: string;
  DL_Created: Date;
  DL_ModifiedBy: string;
  DL_Modified: Date;
  DL_Action: string;
  DL_Tooltip?: any;
  DL_Title: string;
  DL_TableIcon?: any;
  DL_EntityNameForeign: string;
  DL_SequenceNo: string;
  DL_TitleUnique: string;
}
