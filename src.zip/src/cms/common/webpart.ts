﻿import { Observable } from 'rxjs/Rx';
import './rxjs-extensions';
import { DLCMSView } from './models';

export interface WebpartComponent {
  data: DLCMSView;
  // widgetMenuData?: Observable<any>;
}
