import { Injectable } from '@angular/core';

import { Http, URLSearchParams } from '@angular/http';
import { Observable } from 'rxjs/Rx';
import './rxjs-extensions';

// import { EntityBase, DLCMSView } from '../models';
import { environment } from '../../environments/environment';
import { AppConsts } from '@shared/AppConsts';



@Injectable()
export class MetadataService {
  private metaDataAPI: string;
  private apiURL: string;
  private entityName: string;
  private remoteAPI: string = environment.remoteAPI;

  constructor(private http: Http) {
    this.entityName = 'DL_CMSView';
    this.apiURL = '/public/assets/localData/DL_CMSView.json';

    this.metaDataAPI = '/public/assets/localData/DL_CMSView.json';

    if (environment.local === false && environment.production === true) {
      this.apiURL = this.remoteAPI;
      this.metaDataAPI = `${this.remoteAPI}dl_entity=${this.entityName}&strWhere=DL_Id>0&strOrderBy=DL_Sequence`;
    }
  }

  getDataByEntityName(entityName): Observable<any> {
    if (environment.local === false && environment.production === true) {
      this.metaDataAPI = `${this.remoteAPI}dl_entity=${entityName}&strWhere=DL_Id>0&strOrderBy=DL_Sequence`;
    } else {
      this.metaDataAPI = `/public/assets/localData/${entityName}.json`;
    }

    return this.http.get(this.metaDataAPI)
      .map(d => d.json())
      .map(d => d.DL_ENTITYDATA)
      .flatMap(d => {
        if (d[entityName]) {
          return d[entityName];
        } else {
          return Observable.empty();
        }
      });
  }

  // 1 - called from
  getWidgetsByPage(page: any) {

    const that = this;
    if (environment.local === false && environment.production === true) {
      this.metaDataAPI = `${this.remoteAPI}dl_entity=${this.entityName}&strWhere=DL_PageId=${page}&strOrderBy=DL_Sequence`;
    } else {
      this.metaDataAPI = `/public/assets/localData/${this.entityName}.json`;
    }
    // this.metaDataAPI = `${remoteAPI}dl_entity=${this.entityName}&strWhere=DL_PageId=${page}&strOrderBy=DL_Id`;
    return this.http.get(this.metaDataAPI)
      .map(d => d.json())
      .map(data => data.DL_ENTITYDATA)
      .flatMap(data => {
        if (data) {
          if (this.isArray(data.DL_CMSView)) {
            return data.DL_CMSView;
          } else {
            return [data.DL_CMSView];
          }
        } else {
          return Observable.empty();
        }
      });
    // .take(5)


  }

  isArray = (data) => {
    return (Object.prototype.toString.call(data) === '[object Array]');
  }


  public getMenuData() {
    const apiUrl = this.buildActionUri();
    return this.http.get(apiUrl)
      .map(res => res.json())
      .map(d => d.DL_ENTITYDATA)
      .flatMap(d => {
        if (d && d['DL_WidgetMenu'] !== undefined) {
          return this.isArray(d['DL_WidgetMenu'])
            ? d['DL_WidgetMenu'] : [d['DL_WidgetMenu']];
        } else {
          return [{ 'nodata': 'true' }];
        }
      })

  }
  buildActionUri = () => {

    let apiUrl = '/public/assets/actionMenu.json';

    if (environment.production === true && environment.local === false) {
      // apiUrl = `${remoteAPI}DL_WidgetMenu/?OrderBy=DL_Sequence`;
      apiUrl = `${this.remoteAPI}dl_entity=DL_WidgetMenu&strOrderBy=DL_Sequence`;
    }
    return apiUrl;
  }

  private handleError(error: any) {
    const errMsg = (error.message) ? error.message :
      error.status ? `${error.status} - ${error.statusText}` : 'Server error';
    console.error(errMsg);
    return Observable.throw(errMsg);
  }

}
