﻿import {
  Injectable
} from '@angular/core';
import {
  Observable
} from 'rxjs/Rx';
import '../rxjs-extensions';

@Injectable()
export class HelperService {
  constructor() {

  }
  IsString(obj) {
    return obj !== undefined && obj != null && obj.toLowerCase !== undefined;
  }
  // getArgs(str) {
  //     if (!str) {return [];
  //     }
  //     return /\(\s*([^)]+?)\s*\)/.exec(str)[1].split(/\s*,\s*/);
  // }
  getParameterByName = (...args) => {
    let url = '';

    if (!args || !args.length) {
      return null;
    }

    if (args[1] && args[1] === '') {
      url = window.location.href;
    }
    const name = args[0].replace(/[\[\]]/g, '\\$&');
    const regex = new RegExp('[?&]' + name + '(=([^&#]*)|&|#|$)'),
    results = regex.exec(url);
    if (!results) {
      return null
    };
    if (!results[2]) {
      return ''
    };
    return decodeURIComponent(results[2].replace(/\+/g, ' '));
  }
  isArray = (data) => {
    return (Object.prototype.toString.call(data) === '[object Array]');
  }

  buildfn = (func: string, item) => {
    const params = this.getArgs(func);
    params.forEach((v) => {
      const ifString = /["']/g.test(v);
      if (!ifString) {
        func = func.replace(new RegExp(v, 'g'), `'${item[v]}'`);
      }
    });

    return func;
  }



  getFuncResult(func: string, item) {

    const params = this.getArgs(func);
    params.forEach((v) => {
      console.log(v)
      const percentEx = /\%(.*?)\%/;
      const d = v.match(percentEx);
      let keep = '';
      let found = false;
      if (d !== null) {
        v = d.pop();
        found = true;
        keep = `%${v}%`;
      }
      console.log(keep + v);
      if (found) {
        func = func.replace(keep, `'${item[v]}'`);
      }

    });
    return func;

  }

  getArgs(str) {
    return (!str) ? [] : /\(\s*([^)]+?)\s*\)/.exec(str)[1].split(/\s*,\s*/);
  }


}
