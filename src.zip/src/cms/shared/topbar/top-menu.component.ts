﻿import { Component, OnInit, Injector, Input } from '@angular/core';
import { AppComponentBase } from '@shared/app-component-base';
import { Router, ActivatedRoute, RouterState } from '@angular/router';


@Component({
    selector: 'app-top-menu',
    templateUrl: './top-menu.component.html',
    styleUrls: ['./top-menu.component.css']

})
export class TopMenuComponent extends AppComponentBase implements OnInit {
    @Input() pages: Array<any>;

    constructor(
        injector: Injector, private router: Router
    ) {
        super(injector);

    }

    ngOnInit() {
    }

    goToPage(pageNum) {
        this.router.navigate(['/pages'], { queryParams: { page: pageNum } });
    }
}
