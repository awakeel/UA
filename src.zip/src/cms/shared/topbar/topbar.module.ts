import { NgModule, ModuleWithProviders } from '@angular/core';
import { CommonModule } from '@angular/common';
import { LanguageSwitchComponent } from './languageswitch.component';
import { TopMenuComponent } from './top-menu.component';
import { TopBarWithNavComponent } from './topbar-with-nav.component';
import { UserAreaComponent } from './user-area.component';

@NgModule({
  imports: [
    CommonModule
  ],
  declarations: [LanguageSwitchComponent,
    TopMenuComponent, TopBarWithNavComponent, UserAreaComponent],
  exports: [
    TopBarWithNavComponent
  ]
})
export class TopbarModule {
}
