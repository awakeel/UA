﻿
import { Component, Injector, Input, ViewEncapsulation } from '@angular/core';
import { AppComponentBase } from '@shared/app-component-base';
import { LanguageSwitchComponent } from './languageswitch.component';
import { TopMenuComponent } from './top-menu.component';
import { UserAreaComponent } from './user-area.component';

@Component({
    templateUrl: './topbar-with-nav.component.html',
    selector: 'top-bar-with-nav',
    styleUrls: ['./topbar-with-nav.component.css'],
    encapsulation: ViewEncapsulation.None
})
export class TopBarWithNavComponent extends AppComponentBase {
    @Input() _pages: Array<any>;
    constructor(
        injector: Injector
    ) {
        super(injector);
    }

    showLoginName: any;
    ngOnInit() {
        this.showLoginName = this.appSession.getShownLoginName();

    }
}

