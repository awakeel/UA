export * from './widget-menu.component';
