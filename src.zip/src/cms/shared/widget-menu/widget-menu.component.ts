﻿import { DataComponentBase } from 'shared/data-component-base';
import { Component, OnInit, Input, Injector, Output, EventEmitter, AfterViewInit } from '@angular/core';

export interface IDictionary<TValue> {
    [id: string]: TValue;
}
@Component({
    selector: 'app-widget-menu',
    templateUrl: './widget-menu.component.html',
    styleUrls: ['./widget-menu.component.css'],

})
export class WidgetMenuComponent extends DataComponentBase implements AfterViewInit {
    @Input() page: any;
    @Input() dataRow: any;
    @Input() menuData: any[] = [];
    @Input() menuType= 'row';
    @Input() menuDataLoaded = false;
    @Input() view: any;
    @Output() buttonClick = new EventEmitter<any>();

    constructor(injector: Injector) {
        super(injector);
    }
    ngAfterViewInit(): void {
      if (this.menuType === '') {
        this.menuType = 'row';
      }
    }

    onItemClick(event: string, item: any) {

        let DL_Id = '0';
        if (this.page) {
          DL_Id = this.helperService.getParameterByName(this.page);
        }
        const params = this.helperService.getArgs(event);
        params.forEach((v) => {
            const percentEx = /\%(.*?)\%/;
            let d = v.match(percentEx);
            let keep = '';
            let found = false;
            if (d !== null) {
                v = d.pop();
                found = true;
                keep = `%${v}%`;
            }
            console.log(keep + v);
            if (found) {
                event = event.replace(keep, '"' + item[v] + '"');
                console.log(event);
            }
            const hash = /\#(.*?)\#/;
            d = v.match(hash);
              keep = '';
              found = false;
            if (d !== null) {
                v = d.pop();
                found = true;
                keep = `#${v}#`;
            }
            console.log(keep + v);
            if (found) {
                console.log(keep);
                console.log(DL_Id + 'dl id');
                if (!DL_Id) {
                  DL_Id = '0';
                }
                event = event.replace(keep, DL_Id);

            }
        });

        this.buttonClick.emit(event);
        return false;
    }
}
